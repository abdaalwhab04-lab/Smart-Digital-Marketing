/**
 * موجه لوحة التحكم — جميع الإجراءات محمية بصلاحية admin:
 * إدارة الأقسام والأسئلة والإجابات، الإحصائيات، سجل المحادثات مع البحث،
 * العملاء، صندوق البريد، الإعدادات، ومكتبة الصور.
 */
import { z } from "zod";
import { and, asc, desc, eq, like, or, sql, count, gte } from "drizzle-orm";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  categories,
  qaEntries,
  qaAnswers,
  visits,
  conversations,
  messages,
  customers,
  inquiries,
  mediaFiles,
  keywordStats,
} from "@db/schema";
import { getSettings, setSettings } from "./queries/settings";
import { storage } from "./lib/storage";
import { mailerConfigured } from "./lib/mailer";

const answerInput = z.object({
  body: z.string().min(1),
  imageKey: z.string().max(255).nullable().optional(),
  linkUrl: z.string().max(500).nullable().optional(),
  linkLabel: z.string().max(120).nullable().optional(),
  showWhatsapp: z.boolean().default(false),
});

export const adminRouter = createRouter({
  /* ================= الأقسام ================= */
  listCategories: adminQuery.query(async () => {
    const db = getDb();
    const cats = await db
      .select()
      .from(categories)
      .orderBy(asc(categories.sortOrder));
    // عدد الأسئلة لكل قسم
    const counts = await db
      .select({ categoryId: qaEntries.categoryId, c: count() })
      .from(qaEntries)
      .groupBy(qaEntries.categoryId);
    const byCat = new Map(counts.map((x) => [x.categoryId, x.c]));
    return cats.map((c) => ({ ...c, entryCount: byCat.get(c.id) ?? 0 }));
  }),

  createCategory: adminQuery
    .input(
      z.object({
        slug: z.string().min(2).max(64),
        name: z.string().min(2).max(120),
        description: z.string().max(500).optional(),
        icon: z.string().max(60).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const [{ id }] = await getDb().insert(categories).values(input).$returningId();
      return { id };
    }),

  updateCategory: adminQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(2).max(120).optional(),
        description: z.string().max(500).nullable().optional(),
        icon: z.string().max(60).nullable().optional(),
        sortOrder: z.number().optional(),
        isActive: z.boolean().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(categories).set(data).where(eq(categories.id, id));
      return { ok: true };
    }),

  deleteCategory: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const entries = await db
        .select({ id: qaEntries.id })
        .from(qaEntries)
        .where(eq(qaEntries.categoryId, input.id));
      for (const e of entries) {
        await db.delete(qaAnswers).where(eq(qaAnswers.qaId, e.id));
      }
      await db.delete(qaEntries).where(eq(qaEntries.categoryId, input.id));
      await db.delete(categories).where(eq(categories.id, input.id));
      return { ok: true, removedEntries: entries.length };
    }),

  /* ================= الأسئلة والإجابات ================= */
  listEntries: adminQuery
    .input(
      z.object({
        categoryId: z.number().optional(),
        search: z.string().max(200).optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(5).max(100).default(20),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.categoryId) conditions.push(eq(qaEntries.categoryId, input.categoryId));
      if (input.search) conditions.push(like(qaEntries.question, `%${input.search}%`));
      const where = conditions.length ? and(...conditions) : undefined;

      const [{ c: total }] = await db
        .select({ c: count() })
        .from(qaEntries)
        .where(where);

      const rows = await db
        .select()
        .from(qaEntries)
        .where(where)
        .orderBy(desc(qaEntries.updatedAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);

      const ids = rows.map((r) => r.id);
      const answers = ids.length
        ? await db
            .select()
            .from(qaAnswers)
            .where(or(...ids.map((id) => eq(qaAnswers.qaId, id))))
            .orderBy(asc(qaAnswers.sortOrder))
        : [];

      return {
        total,
        page: input.page,
        pageSize: input.pageSize,
        entries: rows.map((r) => ({
          ...r,
          answers: answers.filter((a) => a.qaId === r.id),
        })),
      };
    }),

  createEntry: adminQuery
    .input(
      z.object({
        categoryId: z.number(),
        question: z.string().min(2),
        keywords: z.string().default(""),
        answers: z.array(answerInput).min(1),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [{ id }] = await db
        .insert(qaEntries)
        .values({
          categoryId: input.categoryId,
          question: input.question,
          keywords: input.keywords,
        })
        .$returningId();
      await db.insert(qaAnswers).values(
        input.answers.map((a, i) => ({
          qaId: id,
          body: a.body,
          imageKey: a.imageKey ?? null,
          linkUrl: a.linkUrl ?? null,
          linkLabel: a.linkLabel ?? null,
          showWhatsapp: a.showWhatsapp,
          sortOrder: i,
        })),
      );
      return { id };
    }),

  updateEntry: adminQuery
    .input(
      z.object({
        id: z.number(),
        categoryId: z.number().optional(),
        question: z.string().min(2).optional(),
        keywords: z.string().optional(),
        isActive: z.boolean().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(qaEntries).set(data).where(eq(qaEntries.id, id));
      return { ok: true };
    }),

  deleteEntry: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(qaAnswers).where(eq(qaAnswers.qaId, input.id));
      await db.delete(qaEntries).where(eq(qaEntries.id, input.id));
      return { ok: true };
    }),

  addAnswer: adminQuery
    .input(z.object({ qaId: z.number() }).merge(answerInput))
    .mutation(async ({ input }) => {
      const { qaId, ...a } = input;
      const [{ id }] = await getDb()
        .insert(qaAnswers)
        .values({
          qaId,
          body: a.body,
          imageKey: a.imageKey ?? null,
          linkUrl: a.linkUrl ?? null,
          linkLabel: a.linkLabel ?? null,
          showWhatsapp: a.showWhatsapp,
        })
        .$returningId();
      return { id };
    }),

  updateAnswer: adminQuery
    .input(
      z.object({
        id: z.number(),
        body: z.string().min(1).optional(),
        imageKey: z.string().max(255).nullable().optional(),
        linkUrl: z.string().max(500).nullable().optional(),
        linkLabel: z.string().max(120).nullable().optional(),
        showWhatsapp: z.boolean().optional(),
        sortOrder: z.number().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(qaAnswers).set(data).where(eq(qaAnswers.id, id));
      return { ok: true };
    }),

  deleteAnswer: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(qaAnswers).where(eq(qaAnswers.id, input.id));
      return { ok: true };
    }),

  /* ================= الإحصائيات ================= */
  statsOverview: adminQuery.query(async () => {
    const db = getDb();
    const [{ c: totalVisits }] = await db.select({ c: count() }).from(visits);
    const [{ c: uniqueVisitors }] = await db
      .select({ c: sql<number>`COUNT(DISTINCT ${visits.sessionId})` })
      .from(visits);
    const [{ c: totalConversations }] = await db
      .select({ c: count() })
      .from(conversations);
    const [{ c: totalMessages }] = await db.select({ c: count() }).from(messages);
    const [{ c: totalCustomers }] = await db.select({ c: count() }).from(customers);
    const [{ c: newInquiries }] = await db
      .select({ c: count() })
      .from(inquiries)
      .where(eq(inquiries.status, "new"));
    const [{ c: aiReplies }] = await db
      .select({ c: count() })
      .from(messages)
      .where(eq(messages.source, "ai"));
    const [{ c: kbReplies }] = await db
      .select({ c: count() })
      .from(messages)
      .where(eq(messages.source, "kb"));
    const [{ c: totalQa }] = await db.select({ c: count() }).from(qaEntries);

    // آخر 14 يومًا
    const since = new Date(Date.now() - 13 * 24 * 3600 * 1000);
    since.setHours(0, 0, 0, 0);
    const visitRows = await db
      .select({
        day: sql<string>`DATE(${visits.createdAt})`,
        c: count(),
      })
      .from(visits)
      .where(gte(visits.createdAt, since))
      .groupBy(sql`DATE(${visits.createdAt})`);
    const convRows = await db
      .select({
        day: sql<string>`DATE(${conversations.startedAt})`,
        c: count(),
      })
      .from(conversations)
      .where(gte(conversations.startedAt, since))
      .groupBy(sql`DATE(${conversations.startedAt})`);

    const vMap = new Map(visitRows.map((r) => [r.day, r.c]));
    const cMap = new Map(convRows.map((r) => [r.day, r.c]));
    const daily = Array.from({ length: 14 }, (_, i) => {
      const d = new Date(since.getTime() + i * 24 * 3600 * 1000);
      const key = d.toISOString().slice(0, 10);
      return {
        day: key,
        visits: vMap.get(key) ?? 0,
        conversations: cMap.get(key) ?? 0,
      };
    });

    return {
      totalVisits,
      uniqueVisitors,
      totalConversations,
      totalMessages,
      totalCustomers,
      newInquiries,
      aiReplies,
      kbReplies,
      totalQa,
      daily,
    };
  }),

  topQuestions: adminQuery
    .input(z.object({ limit: z.number().min(3).max(50).default(10) }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select({
          id: qaEntries.id,
          question: qaEntries.question,
          hits: qaEntries.hits,
          category: categories.name,
        })
        .from(qaEntries)
        .leftJoin(categories, eq(qaEntries.categoryId, categories.id))
        .orderBy(desc(qaEntries.hits))
        .limit(input.limit);
    }),

  topKeywords: adminQuery
    .input(z.object({ limit: z.number().min(3).max(100).default(20) }))
    .query(async ({ input }) => {
      return getDb()
        .select()
        .from(keywordStats)
        .orderBy(desc(keywordStats.count))
        .limit(input.limit);
    }),

  /* ================= سجل المحادثات ================= */
  listConversations: adminQuery
    .input(
      z.object({
        search: z.string().max(200).optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(5).max(50).default(15),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      let where;
      if (input.search) {
        const convIds = db
          .select({ id: messages.conversationId })
          .from(messages)
          .where(like(messages.content, `%${input.search}%`))
          .groupBy(messages.conversationId);
        where = or(
          like(conversations.title, `%${input.search}%`),
          sql`${conversations.id} IN (${convIds})`,
        );
      }
      const [{ c: total }] = await db
        .select({ c: count() })
        .from(conversations)
        .where(where);
      const rows = await db
        .select()
        .from(conversations)
        .where(where)
        .orderBy(desc(conversations.lastMessageAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
      return { total, page: input.page, pageSize: input.pageSize, conversations: rows };
    }),

  conversationMessages: adminQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const conv = await db.query.conversations.findFirst({
        where: eq(conversations.id, input.id),
      });
      const msgs = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.id))
        .orderBy(asc(messages.createdAt));
      return { conversation: conv, messages: msgs };
    }),

  deleteConversation: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(messages).where(eq(messages.conversationId, input.id));
      await db.delete(conversations).where(eq(conversations.id, input.id));
      return { ok: true };
    }),

  /* ================= العملاء ================= */
  listCustomers: adminQuery
    .input(
      z.object({
        search: z.string().max(200).optional(),
        status: z.enum(["new", "contacted", "registered", "archived"]).optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(5).max(50).default(15),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.status) conditions.push(eq(customers.status, input.status));
      if (input.search) {
        conditions.push(
          or(
            like(customers.name, `%${input.search}%`),
            like(customers.phone, `%${input.search}%`),
            like(customers.email, `%${input.search}%`),
            like(customers.city, `%${input.search}%`),
            like(customers.country, `%${input.search}%`),
          ),
        );
      }
      const where = conditions.length ? and(...conditions) : undefined;
      const [{ c: total }] = await db
        .select({ c: count() })
        .from(customers)
        .where(where);
      const rows = await db
        .select()
        .from(customers)
        .where(where)
        .orderBy(desc(customers.createdAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
      return { total, page: input.page, pageSize: input.pageSize, customers: rows };
    }),

  updateCustomer: adminQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["new", "contacted", "registered", "archived"]).optional(),
        notes: z.string().nullable().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(customers).set(data).where(eq(customers.id, id));
      return { ok: true };
    }),

  deleteCustomer: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(customers).where(eq(customers.id, input.id));
      return { ok: true };
    }),

  /* ================= صندوق البريد الداخلي ================= */
  listInquiries: adminQuery
    .input(
      z.object({
        status: z.enum(["new", "read", "archived"]).optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(5).max(50).default(15),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const where = input.status ? eq(inquiries.status, input.status) : undefined;
      const [{ c: total }] = await db
        .select({ c: count() })
        .from(inquiries)
        .where(where);
      const rows = await db
        .select()
        .from(inquiries)
        .where(where)
        .orderBy(desc(inquiries.createdAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
      return { total, page: input.page, pageSize: input.pageSize, inquiries: rows };
    }),

  updateInquiry: adminQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["new", "read", "archived"]),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb()
        .update(inquiries)
        .set({ status: input.status })
        .where(eq(inquiries.id, input.id));
      return { ok: true };
    }),

  deleteInquiry: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(inquiries).where(eq(inquiries.id, input.id));
      return { ok: true };
    }),

  /* ================= الإعدادات ================= */
  getSettings: adminQuery.query(async () => {
    const s = await getSettings();
    return {
      whatsapp: s.whatsapp ?? "",
      sponsorCode: s.sponsorCode ?? "",
      registerLink: s.registerLink ?? "",
      notifyEmail: s.notifyEmail ?? "",
      facebook: s.facebook ?? "",
      instagram: s.instagram ?? "",
      aiFallbackEnabled: s.aiFallbackEnabled ?? "true",
      welcomeMessage: s.welcomeMessage ?? "",
      smtpConfigured: mailerConfigured() ? "yes" : "no",
    };
  }),

  updateSettings: adminQuery
    .input(
      z.object({
        whatsapp: z.string().max(30).optional(),
        sponsorCode: z.string().max(30).optional(),
        registerLink: z.string().max(500).optional(),
        notifyEmail: z.string().max(320).optional(),
        facebook: z.string().max(500).optional(),
        instagram: z.string().max(500).optional(),
        aiFallbackEnabled: z.enum(["true", "false"]).optional(),
        welcomeMessage: z.string().max(1000).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await setSettings(input);
      return { ok: true };
    }),

  /* ================= مكتبة الصور ================= */
  listMedia: adminQuery.query(async () => {
    const db = getDb();
    const files = await db
      .select()
      .from(mediaFiles)
      .orderBy(desc(mediaFiles.createdAt))
      .limit(100);
    if (!files.length) return [];
    const keys = files.map((f) => f.key);
    const { urls } = await storage.getPresignedUrls({ keys }).catch(() => ({
      urls: [] as { key: string; url: string }[],
      failures: [],
    }));
    const urlByKey = new Map(urls.map((u) => [u.key, u.url]));
    return files.map((f) => ({ ...f, url: urlByKey.get(f.key) ?? null }));
  }),

  uploadMedia: adminQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        contentBase64: z.string().max(14_000_000), // ~10MB
        contentType: z.string().max(120).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const bytes = Uint8Array.from(Buffer.from(input.contentBase64, "base64"));
      const saved = await storage.uploadFile({
        fileContent: bytes,
        fileName: `chat/${input.name}`,
        contentType: input.contentType,
      });
      const [{ id }] = await getDb()
        .insert(mediaFiles)
        .values({
          key: saved.key,
          name: input.name,
          size: saved.size,
          contentType: input.contentType ?? null,
        })
        .$returningId();
      return { id, key: saved.key, size: saved.size };
    }),

  deleteMedia: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const row = await db.query.mediaFiles.findFirst({
        where: eq(mediaFiles.id, input.id),
      });
      if (row) {
        await storage.deleteFile({ fileKey: row.key }).catch(() => undefined);
        await db.delete(mediaFiles).where(eq(mediaFiles.id, input.id));
      }
      return { ok: true };
    }),
});
