/** قراءة وكتابة إعدادات المنصة (مخزنة في جدول settings) */
import { getDb } from "./connection";
import { settings } from "@db/schema";

let cache: { at: number; data: Record<string, string> } | null = null;
const TTL = 15_000;

export async function getSettings(): Promise<Record<string, string>> {
  if (cache && Date.now() - cache.at < TTL) return cache.data;
  const rows = await getDb().select().from(settings);
  const data: Record<string, string> = {};
  for (const r of rows) data[r.key] = r.value ?? "";
  cache = { at: Date.now(), data };
  return data;
}

export async function setSettings(values: Record<string, string>) {
  const db = getDb();
  for (const [key, value] of Object.entries(values)) {
    await db
      .insert(settings)
      .values({ key, value })
      .onDuplicateKeyUpdate({ set: { value } });
  }
  cache = null;
}

/** الإعدادات المسموح عرضها للزوار (بدون أي أسرار) */
export function publicSettings(s: Record<string, string>) {
  return {
    whatsapp: s.whatsapp || "",
    sponsorCode: s.sponsorCode || "",
    registerLink: s.registerLink || "",
    facebook: s.facebook || "",
    instagram: s.instagram || "",
    welcomeMessage: s.welcomeMessage || "",
    aiFallbackEnabled: s.aiFallbackEnabled !== "false",
  };
}
