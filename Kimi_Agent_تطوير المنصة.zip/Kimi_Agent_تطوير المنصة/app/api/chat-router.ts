/**
 * موجه المحادثة العام — قلب المنصة:
 * - bootstrap: إعدادات عامة + أقسام + رسالة الترحيب
 * - trackVisit: تسجيل الزيارات لإحصائيات الزوار
 * - ask: استقبال سؤال المستخدم، المطابقة الذكية، اختيار إجابة عشوائية،
 *   الاقتراحات، التصعيد للذكاء الاصطناعي، وتسجيل كل شيء في الإحصائيات
 * - submitLead / submitInquiry: نماذج العملاء والبريد الداخلي + إشعار SMTP اختياري
 */
import { z } from "zod";
import { and, eq, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  conversations,
  messages,
  visits,
  customers,
  inquiries,
  keywordStats,
  qaEntries,
} from "@db/schema";
import { getSettings, publicSettings } from "./queries/settings";
import {
  matchQuestion,
  pickRandomAnswer,
  buildSuggestions,
  getActiveCategories,
  applySettingsTokens,
  kbSize,
} from "./chat/engine";
import { tokenize } from "./chat/arabic";
import { generateAiReply } from "./chat/ai";
import { sendNotificationEmail, mailerConfigured } from "./lib/mailer";
import { storage } from "./lib/storage";

const sessionSchema = z.string().min(8).max(64);

/** إنشاء محادثة جديدة أو إعادة استخدام القائمة */
async function ensureConversation(sessionId: string, conversationId?: number) {
  const db = getDb();
  if (conversationId) {
    const existing = await db.query.conversations.findFirst({
      where: and(
        eq(conversations.id, conversationId),
        eq(conversations.sessionId, sessionId),
      ),
    });
    if (existing) return existing.id;
  }
  const [{ id }] = await db
    .insert(conversations)
    .values({ sessionId })
    .$returningId();
  return id;
}

/** تحديث عداد الكلمات المفتاحية من رموز رسالة المستخدم */
async function bumpKeywordStats(text: string) {
  const tokens = [...new Set(tokenize(text))].slice(0, 12);
  if (!tokens.length) return;
  const db = getDb();
  for (const kw of tokens) {
    await db
      .insert(keywordStats)
      .values({ keyword: kw, count: 1 })
      .onDuplicateKeyUpdate({ set: { count: sql`${keywordStats.count} + 1` } });
  }
}

async function imageUrlFor(key: string | null): Promise<string | null> {
  if (!key) return null;
  try {
    const { url } = await storage.getPresignedUrl({ key });
    return url;
  } catch {
    return null;
  }
}

export const chatRouter = createRouter({
  /* ---------- تهيئة واجهة المحادثة ---------- */
  bootstrap: publicQuery.query(async () => {
    const s = await getSettings();
    const cats = await getActiveCategories();
    const size = await kbSize();
    return {
      settings: publicSettings(s),
      categories: cats,
      kbSize: size,
    };
  }),

  /* ---------- تسجيل زيارة ---------- */
  trackVisit: publicQuery
    .input(
      z.object({
        sessionId: sessionSchema,
        path: z.string().max(255).default("/"),
        referrer: z.string().max(500).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb().insert(visits).values({
        sessionId: input.sessionId,
        path: input.path,
        referrer: input.referrer ?? null,
      });
      return { ok: true };
    }),

  /* ---------- السؤال والجواب ---------- */
  ask: publicQuery
    .input(
      z.object({
        sessionId: sessionSchema,
        conversationId: z.number().optional(),
        text: z.string().min(1).max(1000),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const s = await getSettings();
      const convId = await ensureConversation(input.sessionId, input.conversationId);

      // سجل رسالة المستخدم
      await db.insert(messages).values({
        conversationId: convId,
        role: "user",
        content: input.text,
      });
      await bumpKeywordStats(input.text);

      const result = await matchQuestion(input.text);
      const suggestions = await buildSuggestions(result.entry ?? null);

      let replyText = "";
      let source: "kb" | "ai" | "fallback" = "kb";
      let matchedQaId: number | null = null;
      let imageUrl: string | null = null;
      let link: { url: string; label: string } | null = null;
      let showWhatsapp = false;

      if (result.kind === "match" && result.entry) {
        const entry = result.entry;
        matchedQaId = entry.id;
        const answer = pickRandomAnswer(entry);
        replyText = applySettingsTokens(answer.body, s);
        imageUrl = await imageUrlFor(answer.imageKey);
        if (answer.linkUrl) {
          link = {
            url: applySettingsTokens(answer.linkUrl, s),
            label: answer.linkLabel || "اضغط هنا",
          };
        }
        showWhatsapp = answer.showWhatsapp;
        // عداد مرات ظهور السؤال
        await db
          .update(qaEntries)
          .set({ hits: sql`${qaEntries.hits} + 1` })
          .where(eq(qaEntries.id, entry.id));
      } else if (result.kind === "weak" && result.closest?.length) {
        source = "fallback";
        showWhatsapp = true;
        replyText =
          "لم أفهم سؤالك تمامًا 🤔 هل تقصد أحد هذه الأسئلة؟ اختر من الاقتراحات بالأسفل، أو أعد صياغة سؤالك، أو تواصل مع فريقنا مباشرة:";
        // الاقتراحات = أقرب الأسئلة
        suggestions.splice(
          0,
          suggestions.length,
          ...result.closest.map((e) => ({ label: e.question, question: e.question })),
        );
      } else {
        // لا إجابة في القاعدة — الذكاء الاصطناعي ثم التحويل للدعم
        if (s.aiFallbackEnabled !== "false") {
          const ai = await generateAiReply(input.text);
          if (ai.ok && ai.text) {
            source = "ai";
            showWhatsapp = true;
            replyText =
              ai.text +
              "\n\n(ردّ عليك مساعد الذكاء الاصطناعي — للتفاصيل الدقيقة أو الطلب، فريقنا جاهز على واتساب)";
          } else {
            source = "fallback";
            showWhatsapp = true;
            replyText =
              ai.reason === "quota"
                ? "خدمة الذكاء الاصطناعي غير متاحة حاليًا (انتهاء الرصيد)، لكن فريقنا البشري يجيبك مباشرة على واتساب:"
                : "لم أجد إجابة دقيقة في قاعدة معرفتي لهذا السؤال 🙏 أعد صياغته بكلمات أبسط، أو تواصل مع فريقنا مباشرة وسيجيبك فورًا:";
          }
        } else {
          source = "fallback";
          showWhatsapp = true;
          replyText =
            "لم أجد إجابة دقيقة لهذا السؤال 🙏 جرّب صياغة أخرى، أو تواصل مع فريقنا مباشرة:";
        }
      }

      // سجل رد المساعد
      await db.insert(messages).values({
        conversationId: convId,
        role: "bot",
        content: replyText,
        matchedQaId,
        source,
      });
      await db
        .update(conversations)
        .set({
          lastMessageAt: new Date(),
          messageCount: sql`${conversations.messageCount} + 2`,
          title: sql`COALESCE(${conversations.title}, LEFT(${input.text}, 80))`,
        })
        .where(eq(conversations.id, convId));

      return {
        conversationId: convId,
        reply: {
          text: replyText,
          imageUrl,
          link,
          showWhatsapp,
          whatsappUrl: `https://wa.me/${(s.whatsapp || "").replace(/\D/g, "")}?text=${encodeURIComponent("سؤالي: " + input.text)}`,
        },
        suggestions,
        correctedQuery: result.correctedQuery,
      };
    }),

  /* ---------- نموذج جمع بيانات العملاء ---------- */
  submitLead: publicQuery
    .input(
      z.object({
        name: z.string().min(2).max(120),
        phone: z.string().min(5).max(40),
        email: z.string().email().max(320).optional().or(z.literal("")),
        city: z.string().max(120).optional(),
        country: z.string().max(120).optional(),
        interest: z.string().max(120).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(customers).values({
        name: input.name,
        phone: input.phone,
        email: input.email || null,
        city: input.city || null,
        country: input.country || null,
        interest: input.interest || null,
      });

      const body = [
        `الاسم: ${input.name}`,
        `الهاتف: ${input.phone}`,
        input.email ? `البريد: ${input.email}` : null,
        input.city ? `المدينة: ${input.city}` : null,
        input.country ? `الدولة: ${input.country}` : null,
        input.interest ? `الاهتمام: ${input.interest}` : null,
      ]
        .filter(Boolean)
        .join("\n");

      const s = await getSettings();
      let emailSent = false;
      if (s.notifyEmail && mailerConfigured()) {
        emailSent = await sendNotificationEmail({
          to: s.notifyEmail,
          subject: `تسجيل عميل جديد: ${input.name}`,
          text: body,
        });
      }
      await db.insert(inquiries).values({
        type: "registration",
        name: input.name,
        email: input.email || null,
        phone: input.phone,
        subject: "تسجيل اهتمام جديد",
        body,
        emailSent,
      });
      return { ok: true };
    }),

  /* ---------- استفسار عبر نموذج التواصل ---------- */
  submitInquiry: publicQuery
    .input(
      z.object({
        name: z.string().min(2).max(120),
        email: z.string().email().max(320).optional().or(z.literal("")),
        phone: z.string().max(40).optional(),
        subject: z.string().max(255).optional(),
        body: z.string().min(3).max(3000),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const s = await getSettings();
      let emailSent = false;
      if (s.notifyEmail && mailerConfigured()) {
        emailSent = await sendNotificationEmail({
          to: s.notifyEmail,
          subject: `استفسار من ${input.name}${input.subject ? " — " + input.subject : ""}`,
          text: `${input.body}\n\n—\nالبريد: ${input.email || "-"}\nالهاتف: ${input.phone || "-"}`,
        });
      }
      await db.insert(inquiries).values({
        type: "inquiry",
        name: input.name,
        email: input.email || null,
        phone: input.phone || null,
        subject: input.subject || "استفسار عام",
        body: input.body,
        emailSent,
      });
      return { ok: true };
    }),
});
