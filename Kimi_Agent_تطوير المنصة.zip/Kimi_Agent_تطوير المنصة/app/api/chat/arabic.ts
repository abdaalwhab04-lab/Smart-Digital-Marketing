/**
 * أدوات اللغة العربية لمحرك البحث:
 * تطبيع النص، كلمات الوقف، مجموعات المرادفات، وتصحيح الأخطاء الإملائية
 * (مسافة داميراو-ليفنشتاين مع حد أقصى 1 تعديل متجاور).
 */

/** تطبيع النص العربي: توحيد الحروف وإزالة التشكيل والتطويل والرموز */
export function normalizeArabic(text: string): string {
  return (text || "")
    .toLowerCase()
    .replace(/[ً-ْٰـ]/g, "") // تشكيل + تطويل
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/گ/g, "ك")
    .replace(/چ/g, "ج")
    .replace(/پ/g, "ب")
    .replace(/ماهي/g, "ما هي")
    .replace(/ماهو/g, "ما هو")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** كلمات لا تحمل معنى بحثيًا */
export const STOP_WORDS = new Set([
  "ما", "ماذا", "هي", "هو", "من", "في", "عن", "على", "الي", "الى", "هل", "كيف",
  "متى", "اين", "لماذا", "ليش", "ليه", "ذا", "ذلك", "هذا", "هذه", "التي",
  "الذي", "او", "ثم", "قد", "لقد", "كل", "بعض", "غير", "بين", "عند", "مع",
  "انا", "انت", "نحن", "هو", "يا", "اي", "لك", "لي", "له", "لها", "بكم", "كم",
  "و", "ف", "ب", "ل", "ك", "the", "is", "a", "an", "of", "to", "in", "and",
]);

export function tokenize(text: string): string[] {
  return normalizeArabic(text)
    .split(" ")
    .filter((w) => w.length > 1 && !STOP_WORDS.has(w));
}

/**
 * تجريد البادئات الشائعة (ال، ب، ل، و، ف، بال، هال) لتغطية اللهجات:
 * «بيكسب» → «يكسب»، «هالمشروع» → «مشروع»، «والقهوه» → «قهوه»
 */
export function stripPrefixes(word: string): string[] {
  const variants: string[] = [];
  const prefixes = ["هال", "بال", "وال", "فال", "ال"];
  for (const p of prefixes) {
    if (word.startsWith(p) && word.length - p.length >= 3) {
      variants.push(word.slice(p.length));
    }
  }
  if (word.length >= 4 && /^[بلوف]/.test(word) && !word.startsWith("ال")) {
    variants.push(word.slice(1));
  }
  return variants;
}

/** كل صيغ الكلمة المقبولة للمطابقة (الأصل + المجردة) */
export function tokenVariants(word: string): string[] {
  return [word, ...stripPrefixes(word)];
}

/**
 * مجموعات المرادفات — كل مجموعة مفهوم واحد بصيغه المختلفة.
 * تُستخدم لتوسيع الاستعلام: مطابقة أي عضو تقرّب بقية الأعضاء.
 */
export const SYNONYM_GROUPS: string[][] = [
  ["ربح", "ارباح", "مكسب", "دخل", "فلوس", "عموله", "عمولة", "بونص", "كسب", "يكسب", "بيكسب", "كسبان"],
  ["اريد", "عايز", "عاوز", "ابغي", "ابي", "بدي", "ارغب", "حابب"],
  ["سعر", "اسعار", "ثمن", "تكلفه", "تكلفة", "price", "بكم"],
  ["تسجيل", "اشتراك", "انضمام", "عضويه", "عضوية", "تسجل", "سجل", "اشترك", "انضم"],
  ["منتج", "منتجات", "منتجون", "بضاعه", "سلع"],
  ["قهوه", "قهوة", "كوفي", "coffee", "لينجزي"],
  ["شحن", "توصيل", "شحنه", "توصيله", "ديليفري"],
  ["تدريب", "تعلم", "دوره", "دورة", "كورس", "تاهيل"],
  ["واتساب", "واتس", "whatsapp", "واتسب", "وتساب"],
  ["شركه", "شركة", "مؤسسه", "موسسه"],
  ["راعي", "سبونسر", "sponsor", "كفيل"],
  ["وظيفه", "وظيفة", "عمل", "شغل", "فرصه", "فرصة", "اشتغل", "يشتغل", "وظايف"],
  ["رتبه", "رتبة", "مستوي", "مستوى", "نجم", "دايموند"],
  ["فوائد", "فوايد", "مميزات", "مزايا", "منفعه", "منفعة"],
  ["استخدام", "استعمال", "طريقه", "طريقة", "جرعه", "جرعة"],
  ["نصب", "احتيال", "نصابه", "خداع", "هرمي", "هرميه", "هرمية"],
  ["حلال", "حرام", "حكم", "شرعي", "فتوي", "فتوى"],
  ["مبتدي", "مبتدئ", "جديد", "بدايه", "بداية", "ابدا", "ابدأ"],
  ["فطر", "جانوديرما", "ريشي", "ريشى", "ganoderma", "reishi"],
  ["سبيرولينا", "سبيرولينا", "spirulina", "طحالب"],
  ["كورديسبس", "كورديسيبس", "cordyceps"],
  ["تواصل", "اتصال", "اكلم", "مراسله", "مراسلة", "ايميل", "بريد"],
  ["استرجاع", "ارجاع", "استبدال", "مرتجع", "استرداد"],
  ["زائر", "موزع", "عضو", "مشترك"],
  ["فريق", "شبكه", "شبكة", "داونلاين", "downline"],
];

/** خريطة كلمة → مجموعة مرادفاتها (تُبنى مرة واحدة) */
const SYN_MAP = new Map<string, string[]>();
for (const group of SYNONYM_GROUPS) {
  for (const w of group) SYN_MAP.set(normalizeArabic(w), group.map(normalizeArabic));
}

/** إرجاع مرادفات الكلمة (بدون الكلمة نفسها) */
export function synonymsOf(word: string): string[] {
  const g = SYN_MAP.get(normalizeArabic(word));
  return g ? g.filter((x) => x !== normalizeArabic(word)) : [];
}

/**
 * مسافة داميراو-ليفنشتاين (تدعم تبديل حرفين متجاورين — خطأ شائع في الكتابة السريعة)
 * مع إيقاف مبكر عند تجاوز الحد.
 */
export function damerauLevenshtein(a: string, b: string, maxDist = 2): number {
  const al = a.length;
  const bl = b.length;
  if (Math.abs(al - bl) > maxDist) return maxDist + 1;

  const dp: number[][] = Array.from({ length: al + 1 }, (_, i) =>
    Array.from({ length: bl + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0)),
  );

  for (let i = 1; i <= al; i++) {
    let rowMin = Infinity;
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      let v = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost,
      );
      if (
        i > 1 &&
        j > 1 &&
        a[i - 1] === b[j - 2] &&
        a[i - 2] === b[j - 1]
      ) {
        v = Math.min(v, dp[i - 2][j - 2] + 1);
      }
      dp[i][j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > maxDist) return maxDist + 1;
  }
  return dp[al][bl];
}

/** الحد المسموح لتصحيح كلمة بطول معين */
export function typoTolerance(word: string): number {
  if (word.length <= 3) return 0;
  if (word.length <= 6) return 1;
  return 2;
}
