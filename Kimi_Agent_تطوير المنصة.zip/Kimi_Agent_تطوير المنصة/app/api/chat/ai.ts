/**
 * رد الاحتياط بالذكاء الاصطناعي — يُستدعى فقط عندما لا تجد قاعدة المعرفة إجابة.
 * يمر عبر بوابة المنصة (المفتاح خادمي فقط) ويستخدم معرّف النموذج الافتراضي
 * من listModels() — لا معرّفات ثابتة.
 */
import { generateText } from "ai";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { listModels, classifyAiError, AiUnavailable } from "../lib/ai-client";

const SYSTEM_PROMPT = `أنت «مساعد DXN الذكي» في منصة تسويق شبكي عربية لمنتجات شركة DXN الماليزية (مكملات الجانوديرما، القهوة الصحية، العناية الشخصية).

قواعد صارمة:
- أجب بالعربية الفصحى المبسطة، بأسلوب ودود ومهني، في 2-4 جمل قصيرة كحد أقصى.
- التزم بمجال المنصة: منتجات DXN، التسجيل، فرصة العمل، التسويق الشبكي، الشحن، التدريب.
- لا تخترع أسعارًا أو أرقامًا أو وعودًا طبية؛ المكملات ليست دواء ولا تعالج أمراضًا.
- عند السؤال عن السعر أو الطلب أو بلد معين: وجّه المستخدم لفريق الواتساب.
- إذا كان السؤال خارج نطاق المنصة تمامًا: اعتذر بلطف ووجّه المستخدم لصياغة سؤال عن المنتجات أو فرصة العمل.`;

export interface AiReply {
  ok: boolean;
  text?: string;
  /** نوع الفشل لعرض رسالة مناسبة في الواجهة */
  reason?: "quota" | "transient" | "other";
}

export async function generateAiReply(userQuestion: string): Promise<AiReply> {
  try {
    const { defaultModelId } = await listModels();
    const provider = createOpenAICompatible({
      name: "kimi-gw",
      baseURL: process.env.KIMI_AGENTGW_BASE_URL!,
      apiKey: process.env.KIMI_AGENTGW_API_KEY!,
    });
    const { text } = await generateText({
      model: provider(defaultModelId),
      system: SYSTEM_PROMPT,
      prompt: userQuestion,
      maxOutputTokens: 300,
    });
    const clean = (text || "").trim();
    if (!clean) return { ok: false, reason: "other" };
    return { ok: true, text: clean };
  } catch (err) {
    const classified = classifyAiError(err);
    if (classified instanceof AiUnavailable) return { ok: false, reason: "quota" };
    return { ok: false, reason: classified.name === "AiTransient" ? "transient" : "other" };
  }
}
