/**
 * محرك المطابقة الذكي:
 * يحمّل قاعدة المعرفة من MySQL (مع كاش قصير العمر)، يطابق سؤال المستخدم
 * باستخدام التطبيع + الكلمات المفتاحية + المرادفات + تصحيح الأخطاء،
 * ويعيد إجابة عشوائية من إجابات السؤال المتعددة مع اقتراحات سياقية.
 */
import { getDb } from "../queries/connection";
import { categories, qaEntries, qaAnswers } from "@db/schema";
import { eq, asc } from "drizzle-orm";
import {
  normalizeArabic,
  tokenize,
  synonymsOf,
  damerauLevenshtein,
  typoTolerance,
  stripPrefixes,
} from "./arabic";

export interface KbAnswer {
  id: number;
  body: string;
  imageKey: string | null;
  linkUrl: string | null;
  linkLabel: string | null;
  showWhatsapp: boolean;
}

export interface KbEntry {
  id: number;
  categoryId: number;
  question: string;
  normQuestion: string;
  questionTokens: string[];
  keywords: string[];
  keywordNorms: string[];
  answers: KbAnswer[];
}

export interface KbCategory {
  id: number;
  slug: string;
  name: string;
  icon: string | null;
}

interface Cache {
  at: number;
  entries: KbEntry[];
  categories: KbCategory[];
  vocab: Map<string, number>;
}

let cache: Cache | null = null;
const CACHE_TTL = 30_000; // 30 ثانية — تعديلات لوحة التحكم تظهر سريعًا

async function loadKb(): Promise<Cache> {
  if (cache && Date.now() - cache.at < CACHE_TTL) return cache;

  const db = getDb();
  const cats = await db
    .select()
    .from(categories)
    .where(eq(categories.isActive, true))
    .orderBy(asc(categories.sortOrder));
  const entries = await db
    .select()
    .from(qaEntries)
    .where(eq(qaEntries.isActive, true));
  const answers = await db.select().from(qaAnswers).orderBy(asc(qaAnswers.sortOrder));

  const answersByQa = new Map<number, KbAnswer[]>();
  for (const a of answers) {
    const list = answersByQa.get(a.qaId) ?? [];
    list.push({
      id: a.id,
      body: a.body,
      imageKey: a.imageKey,
      linkUrl: a.linkUrl,
      linkLabel: a.linkLabel,
      showWhatsapp: a.showWhatsapp,
    });
    answersByQa.set(a.qaId, list);
  }

  const vocab = new Map<string, number>();
  const addVocab = (w: string) => vocab.set(w, (vocab.get(w) ?? 0) + 1);

  const kbEntries: KbEntry[] = entries
    .map((e) => {
      const normQuestion = normalizeArabic(e.question);
      const questionTokens = tokenize(e.question);
      const keywords = e.keywords
        .split(/[,،]/)
        .map((k) => k.trim())
        .filter(Boolean);
      const keywordNorms = keywords.map(normalizeArabic).filter(Boolean);
      questionTokens.forEach(addVocab);
      keywordNorms.forEach((k) => tokenize(k).forEach(addVocab));
      return {
        id: e.id,
        categoryId: e.categoryId,
        question: e.question,
        normQuestion,
        questionTokens,
        keywords,
        keywordNorms,
        answers: answersByQa.get(e.id) ?? [],
      };
    })
    .filter((e) => e.answers.length > 0);

  cache = {
    at: Date.now(),
    entries: kbEntries,
    categories: cats.map((c) => ({
      id: c.id,
      slug: c.slug,
      name: c.name,
      icon: c.icon,
    })),
    vocab,
  };
  return cache;
}

/** تصحيح إملائي لكلمة استعلام باستخدام مفردات قاعدة المعرفة */
function correctToken(token: string, vocab: Map<string, number>): string {
  if (vocab.has(token)) return token;
  const tol = typoTolerance(token);
  if (tol === 0) return token;
  let best = token;
  let bestDist = tol + 1;
  let bestFreq = 0;
  for (const [word, freq] of vocab) {
    if (Math.abs(word.length - token.length) > tol) continue;
    const d = damerauLevenshtein(token, word, tol);
    if (d < bestDist || (d === bestDist && freq > bestFreq)) {
      best = word;
      bestDist = d;
      bestFreq = freq;
    }
  }
  return bestDist <= tol ? best : token;
}

export interface MatchResult {
  kind: "match" | "weak" | "none";
  entry?: KbEntry;
  score?: number;
  /** عند الضعف: أقرب الأسئلة للاقتراح */
  closest?: KbEntry[];
  /** الاستعلام بعد التصحيح الإملائي (للعرض) */
  correctedQuery?: string;
}

function scoreEntry(
  queryNorm: string,
  rawTokens: string[],
  correctedTokens: string[],
  entry: KbEntry,
  vocab: Map<string, number>,
): number {
  let s = 0;

  if (queryNorm === entry.normQuestion) s += 120;
  // مكافأة الاحتواء — بشرط أن يغطي الجزء المشترك نصف النص الأطول على الأقل،
  // حتى لا تتفوق الأسئلة العامة القصيرة («المنتجات») على أسئلة أدق.
  const [shorter, longer] =
    queryNorm.length <= entry.normQuestion.length
      ? [queryNorm, entry.normQuestion]
      : [entry.normQuestion, queryNorm];
  if (
    shorter.length >= 4 &&
    longer.includes(shorter) &&
    shorter.length / longer.length >= 0.5
  ) {
    s += 45;
  }

  const entryTokens = new Set(entry.questionTokens);
  const correctedSet = new Set(correctedTokens);

  // تطابق الرموز (بعد التصحيح) مع نص السؤال
  for (const t of correctedTokens) {
    if (entryTokens.has(t)) s += 9;
  }

  // الكلمات المفتاحية — تُحتسب أفضل مطابقة واحدة فقط حتى لا تتراكم
  // مرادفات الجذر الواحد («منتج»، «منتجات»، «المنتجات») وتُطفئ الأسئلة الأدق.
  // الكلمة النادرة في القاعدة أعلى دلالة فتُرجَّح.
  let kwBest = 0;
  for (const kn of entry.keywordNorms) {
    if (!kn) continue;
    if (queryNorm.includes(kn)) {
      const rare = (vocab.get(kn) ?? 0) <= 3;
      const v = rare ? 24 : 16;
      if (v > kwBest) kwBest = v;
      continue;
    }
    const kTokens = tokenize(kn);
    let tokHits = 0;
    for (const kt of kTokens) {
      if (correctedSet.has(kt)) tokHits++;
    }
    if (tokHits > 0) {
      const v = Math.min(5 * tokHits, 12);
      if (v > kwBest) kwBest = v;
    }
  }
  s += kwBest;

  // المرادفات: كلمة في الاستعلام (أو تصحيحها/تجريدها) لها مرادف في السؤال أو الكلمات المفتاحية — بسقف أقصى
  const synSources = new Set([...rawTokens, ...correctedTokens]);
  let synScore = 0;
  for (const t of synSources) {
    for (const syn of synonymsOf(t)) {
      if (entryTokens.has(syn)) synScore += 6;
      else {
        for (const kn of entry.keywordNorms) {
          if (kn.includes(syn)) {
            synScore += 4;
            break;
          }
        }
      }
    }
  }
  s += Math.min(synScore, 12);

  return s;
}

const MATCH_THRESHOLD = 15;
const WEAK_THRESHOLD = 8;

export async function matchQuestion(query: string): Promise<MatchResult> {
  const kb = await loadKb();
  const queryNorm = normalizeArabic(query);
  if (!queryNorm) return { kind: "none" };

  const rawTokens = tokenize(query);
  // تصحيح إملائي لكل رمز + توسيعه بصيغه المجردة من البادئات
  const correctedTokens = [
    ...new Set(
      rawTokens.flatMap((t) => {
        const c = correctToken(t, kb.vocab);
        return [c, ...stripPrefixes(c)];
      }),
    ),
  ];
  const correctedQuery = correctedTokens.join(" ");

  const scored: { entry: KbEntry; score: number }[] = [];
  for (const entry of kb.entries) {
    const s = scoreEntry(queryNorm, rawTokens, correctedTokens, entry, kb.vocab);
    if (s > 0) scored.push({ entry, score: s });
  }
  scored.sort((a, b) => b.score - a.score);

  const top = scored[0];
  if (top && top.score >= MATCH_THRESHOLD) {
    return {
      kind: "match",
      entry: top.entry,
      score: top.score,
      correctedQuery: correctedQuery !== rawTokens.join(" ") ? correctedQuery : undefined,
    };
  }
  if (top && top.score >= WEAK_THRESHOLD) {
    return {
      kind: "weak",
      closest: scored.slice(0, 3).map((x) => x.entry),
      score: top.score,
    };
  }
  return { kind: "none" };
}

/** اختيار إجابة عشوائية من إجابات السؤال (المتطلب: عدم تكرار نفس الرد) */
export function pickRandomAnswer(entry: KbEntry): KbAnswer {
  return entry.answers[Math.floor(Math.random() * entry.answers.length)];
}

/** اقتراحات سياقية بعد الإجابة: أسئلة أخرى من نفس القسم + إجراءات منطقية */
export async function buildSuggestions(
  matchedEntry: KbEntry | null,
): Promise<{ label: string; question: string }[]> {
  const kb = await loadKb();
  const out: { label: string; question: string }[] = [];

  if (matchedEntry) {
    const siblings = kb.entries.filter(
      (e) => e.categoryId === matchedEntry.categoryId && e.id !== matchedEntry.id,
    );
    // اختيار عشوائي لسؤالين من نفس القسم
    for (let i = siblings.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [siblings[i], siblings[j]] = [siblings[j], siblings[i]];
    }
    for (const sib of siblings.slice(0, 2)) {
      out.push({ label: sib.question, question: sib.question });
    }

    const cat = kb.categories.find((c) => c.id === matchedEntry.categoryId);
    if (cat?.slug === "products") {
      out.push({ label: "هل تريد معرفة الأسعار؟", question: "ما هي الأسعار؟" });
      out.push({ label: "هل تريد التسجيل؟", question: "كيف أسجل في DXN؟" });
    } else if (cat?.slug === "registration") {
      out.push({ label: "ما هي المنتجات؟", question: "ما هي منتجات DXN؟" });
    } else if (cat?.slug === "profits") {
      out.push({ label: "كيف أبدأ الآن؟", question: "كيف أسجل في DXN؟" });
    }
  } else {
    out.push(
      { label: "المنتجات", question: "ما هي منتجات DXN؟" },
      { label: "التسجيل", question: "كيف أسجل في DXN؟" },
      { label: "الأرباح", question: "كيف أربح من DXN؟" },
    );
  }
  return out.slice(0, 4);
}

export async function getActiveCategories(): Promise<KbCategory[]> {
  return (await loadKb()).categories;
}

/** عدد الأسئلة والإجابات النشطة (للعرض في الواجهة) */
export async function kbSize(): Promise<{ entries: number; answers: number }> {
  const kb = await loadKb();
  return {
    entries: kb.entries.length,
    answers: kb.entries.reduce((n, e) => n + e.answers.length, 0),
  };
}

/** استبدال رموز الإعدادات داخل نص الإجابة */
export function applySettingsTokens(
  text: string,
  s: Record<string, string>,
): string {
  return text
    .replaceAll("{{register}}", s.registerLink || "")
    .replaceAll("{{whatsapp}}", s.whatsapp || "")
    .replaceAll("{{sponsor}}", s.sponsorCode || "");
}
