/**
 * إشعارات البريد الإلكتروني الاختيارية عبر SMTP.
 *
 * تُفعَّل فقط عند توفر متغير البيئة SMTP_URL بصيغة:
 *   smtp://user:pass@host:port   أو   smtps://user:pass@host:port
 * عند غيابه تُحفظ الاستفسارات في صندوق البريد الداخلي (لوحة التحكم)
 * ويعمل كل شيء دون بريد خارجي — لا فشل صامت ولا استثناءات.
 */
import nodemailer from "nodemailer";
import { log } from "./logger";

function smtpUrl(): string | undefined {
  const proc = (globalThis as { process?: { env?: Record<string, string | undefined> } })
    .process;
  return proc?.env?.SMTP_URL || undefined;
}

export function mailerConfigured(): boolean {
  return Boolean(smtpUrl());
}

/**
 * إرسال إشعار بريدي. يعيد true عند النجاح، وfalse عند غياب الإعداد أو الفشل
 * (مع تسجيل الخطأ) — لا يرمي أبدًا حتى لا يسقط طلب المستخدم بسبب البريد.
 */
export async function sendNotificationEmail(opts: {
  to: string;
  subject: string;
  text: string;
}): Promise<boolean> {
  const url = smtpUrl();
  if (!url || !opts.to) return false;
  try {
    const transporter = nodemailer.createTransport(url);
    await transporter.sendMail({
      from: process.env.SMTP_FROM || opts.to,
      to: opts.to,
      subject: opts.subject,
      text: opts.text,
    });
    return true;
  } catch (err) {
    log.error("email send failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return false;
  }
}
