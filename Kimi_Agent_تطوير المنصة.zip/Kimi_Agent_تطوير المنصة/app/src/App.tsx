import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import ChatPage from './pages/ChatPage'
import Login from "./pages/Login"
import NotFound from "./pages/NotFound"
import AdminLayout from "./pages/admin/AdminLayout"
import Dashboard from "./pages/admin/Dashboard"
import Knowledge from "./pages/admin/Knowledge"
import Conversations from "./pages/admin/Conversations"
import Customers from "./pages/admin/Customers"
import InboxPage from "./pages/admin/Inbox"
import MediaLibrary from "./pages/admin/MediaLibrary"
import SettingsPage from "./pages/admin/SettingsPage"

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/chat" element={<ChatPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="knowledge" element={<Knowledge />} />
        <Route path="conversations" element={<Conversations />} />
        <Route path="customers" element={<Customers />} />
        <Route path="inbox" element={<InboxPage />} />
        <Route path="media" element={<MediaLibrary />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
