/** ترويسة الموقع وتذييله — مشتركة بين الصفحات العامة */
import { Link, useLocation } from "react-router";
import { useState } from "react";
import { Menu, X, Leaf, MessageCircle } from "lucide-react";
import { trpc } from "@/providers/trpc";

const NAV = [
  { to: "/", label: "الرئيسية" },
  { to: "/chat", label: "المساعد الذكي" },
  { to: "/#products", label: "المنتجات" },
  { to: "/#opportunity", label: "فرصة العمل" },
  { to: "/#register", label: "سجّل اهتمامك" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { data: boot } = trpc.chat.bootstrap.useQuery();

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link to="/" className="flex items-center gap-2 font-black text-lg text-primary">
          <span className="grid place-items-center w-9 h-9 rounded-xl bg-primary text-primary-foreground">
            <Leaf className="w-5 h-5" />
          </span>
          منصة DXN الذكية
        </Link>

        <nav className="hidden md:flex items-center gap-1" aria-label="التنقل الرئيسي">
          {NAV.map((n) => (
            <Link
              key={n.label}
              to={n.to}
              className={`rounded-full px-3.5 py-2 text-sm font-medium transition-colors hover:bg-secondary ${
                location.pathname === n.to ? "text-primary font-bold" : "text-foreground"
              }`}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {boot?.settings.whatsapp && (
            <a
              href={`https://wa.me/${boot.settings.whatsapp.replace(/\D/g, "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:flex items-center gap-1.5 rounded-full bg-[#25D366] px-4 py-2 text-sm font-bold text-white hover:brightness-95 transition"
            >
              <MessageCircle className="w-4 h-4" />
              واتساب
            </a>
          )}
          <button
            className="md:hidden p-2 rounded-lg hover:bg-secondary cursor-pointer"
            onClick={() => setOpen((o) => !o)}
            aria-label="القائمة"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="md:hidden border-t border-border bg-background px-4 py-2" aria-label="قائمة الجوال">
          {NAV.map((n) => (
            <Link
              key={n.label}
              to={n.to}
              onClick={() => setOpen(false)}
              className="block rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-secondary"
            >
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  const { data: boot } = trpc.chat.bootstrap.useQuery();
  const s = boot?.settings;
  return (
    <footer className="border-t border-border bg-sidebar-background text-sidebar-foreground mt-16">
      <div className="mx-auto max-w-6xl px-4 py-10 grid gap-8 sm:grid-cols-3">
        <div>
          <p className="flex items-center gap-2 font-black text-lg text-sidebar-primary">
            <Leaf className="w-5 h-5" />
            منصة DXN الذكية
          </p>
          <p className="mt-2 text-sm opacity-75 leading-relaxed">
            منصة تسويق شبكي احترافية بمساعد ذكاء اصطناعي يجيب فورًا عن أسئلتك
            حول منتجات DXN وفرصة العمل، على مدار الساعة.
          </p>
        </div>
        <div>
          <p className="font-bold mb-3">روابط سريعة</p>
          <ul className="space-y-2 text-sm opacity-85">
            <li><Link to="/chat" className="hover:text-sidebar-primary transition-colors">المساعد الذكي</Link></li>
            <li><Link to="/#products" className="hover:text-sidebar-primary transition-colors">المنتجات</Link></li>
            <li><Link to="/#register" className="hover:text-sidebar-primary transition-colors">سجّل اهتمامك</Link></li>
            <li><Link to="/login" className="hover:text-sidebar-primary transition-colors">لوحة التحكم</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-bold mb-3">تواصل معنا</p>
          <ul className="space-y-2 text-sm opacity-85">
            {s?.whatsapp && (
              <li>
                <a
                  href={`https://wa.me/${s.whatsapp.replace(/\D/g, "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-sidebar-primary transition-colors latin"
                  dir="ltr"
                >
                  +{s.whatsapp}
                </a>
              </li>
            )}
            {s?.facebook && (
              <li><a href={s.facebook} target="_blank" rel="noopener noreferrer" className="hover:text-sidebar-primary transition-colors">فيسبوك</a></li>
            )}
            {s?.instagram && (
              <li><a href={s.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-sidebar-primary transition-colors">إنستغرام</a></li>
            )}
          </ul>
        </div>
      </div>
      <div className="border-t border-sidebar-border py-4 text-center text-xs opacity-60">
        منصة التسويق الشبكي الذكية © {new Date().getFullYear()} — جميع الحقوق محفوظة
      </div>
    </footer>
  );
}
