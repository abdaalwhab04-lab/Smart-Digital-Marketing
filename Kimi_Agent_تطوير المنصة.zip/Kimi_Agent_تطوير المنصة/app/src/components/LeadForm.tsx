/**
 * نموذج جمع بيانات العملاء (الاسم، الهاتف، البريد، المدينة، الدولة، الاهتمام)
 * يحفظ في قاعدة البيانات ويُنشئ إشعار تسجيل في صندوق بريد لوحة التحكم.
 */
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle2, Loader2 } from "lucide-react";

const INTERESTS = [
  "شراء المنتجات",
  "فرصة العمل والدخل الإضافي",
  "الاثنان معًا",
  "أريد الاستفسار أولًا",
];

export function LeadForm() {
  const submit = trpc.chat.submitLead.useMutation();
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    city: "",
    country: "",
    interest: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  function validate() {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 2) e.name = "أدخل الاسم الكامل";
    if (form.phone.trim().length < 5) e.phone = "أدخل رقم هاتف صحيح";
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      e.email = "صيغة البريد غير صحيحة";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function onSubmit(ev: React.FormEvent) {
    ev.preventDefault();
    if (!validate()) return;
    submit.mutate(
      {
        name: form.name.trim(),
        phone: form.phone.trim(),
        email: form.email.trim(),
        city: form.city.trim(),
        country: form.country.trim(),
        interest: form.interest,
      },
      { onSuccess: () => setDone(true) },
    );
  }

  if (done) {
    return (
      <div className="rounded-2xl border border-accent bg-accent/10 p-8 text-center msg-enter">
        <CheckCircle2 className="w-12 h-12 mx-auto text-primary" />
        <h3 className="mt-3 text-xl font-black text-primary">تم استلام بياناتك بنجاح 🎉</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          سيتواصل معك فريقنا خلال ساعات قريبة. ويمكنك الآن تجربة المساعد الذكي
          للتعرف على المنتجات أكثر.
        </p>
      </div>
    );
  }

  const field = (key: keyof typeof form, label: string, props: React.InputHTMLAttributes<HTMLInputElement> = {}) => (
    <div className="space-y-1.5">
      <Label htmlFor={`lead-${key}`}>{label}</Label>
      <Input
        id={`lead-${key}`}
        value={form[key]}
        onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
        className="bg-background"
        {...props}
      />
      {errors[key] && <p className="text-xs text-destructive">{errors[key]}</p>}
    </div>
  );

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8 shadow-sm space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        {field("name", "الاسم الكامل *", { placeholder: "مثال: أحمد محمد", required: true })}
        {field("phone", "رقم الهاتف (واتساب) *", {
          placeholder: "09XXXXXXXX",
          dir: "ltr",
          className: "bg-background latin text-left",
          required: true,
        })}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {field("email", "البريد الإلكتروني", {
          type: "email",
          placeholder: "you@example.com",
          dir: "ltr",
          className: "bg-background latin text-left",
        })}
        <div className="space-y-1.5">
          <Label>مجال الاهتمام</Label>
          <Select value={form.interest} onValueChange={(v) => setForm((f) => ({ ...f, interest: v }))}>
            <SelectTrigger className="bg-background">
              <SelectValue placeholder="اختر اهتمامك" />
            </SelectTrigger>
            <SelectContent>
              {INTERESTS.map((i) => (
                <SelectItem key={i} value={i}>{i}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {field("city", "المدينة", { placeholder: "مثال: طرابلس" })}
        {field("country", "الدولة", { placeholder: "مثال: ليبيا" })}
      </div>
      {submit.isError && (
        <p className="text-sm text-destructive">تعذر الإرسال، حاول مرة أخرى.</p>
      )}
      <Button
        type="submit"
        disabled={submit.isPending}
        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-12 text-base cursor-pointer"
      >
        {submit.isPending ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          "سجّل اهتمامك الآن — مجانًا"
        )}
      </Button>
      <p className="text-[11px] text-center text-muted-foreground">
        بياناتك بأمان وتُستخدم فقط للتواصل معك بخصوص المنتجات وفرصة العمل.
      </p>
    </form>
  );
}
