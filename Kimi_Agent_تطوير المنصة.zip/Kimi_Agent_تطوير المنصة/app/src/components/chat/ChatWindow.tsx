/**
 * نافذة المحادثة الأساسية — تُستخدم في الودجت العائم وصفحة المحادثة الكاملة.
 * تشمل: الأزرار السريعة، الاقتراحات الذكية، الصور والروابط، زر واتساب،
 * مؤشر الكتابة، وتصحيح «هل تقصد».
 */
import { useEffect, useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { getSessionId } from "@/lib/session";
import {
  Send,
  MessageCircle,
  Package,
  UserPlus,
  Coins,
  TrendingUp,
  GraduationCap,
  Headset,
  ExternalLink,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChatMessage {
  id: string;
  role: "user" | "bot";
  text: string;
  imageUrl?: string | null;
  link?: { url: string; label: string } | null;
  whatsappUrl?: string | null;
  correctedQuery?: string;
}

interface Suggestion {
  label: string;
  question: string;
}

const QUICK_BUTTONS = [
  { label: "المنتجات", question: "ما هي منتجات DXN؟", icon: Package },
  { label: "التسجيل", question: "كيف أسجل في DXN؟", icon: UserPlus },
  { label: "الأسعار", question: "ما هي الأسعار؟", icon: Coins },
  { label: "الأرباح", question: "كيف أربح من DXN؟", icon: TrendingUp },
  { label: "التدريب", question: "هل يوجد تدريب للمبتدئين؟", icon: GraduationCap },
  { label: "التواصل", question: "كيف أتواصل معكم؟", icon: Headset },
];

let uid = 0;
const nextId = () => `m-${++uid}-${Date.now()}`;

export function ChatWindow({
  fullPage = false,
  initialQuestion,
}: {
  fullPage?: boolean;
  initialQuestion?: string;
}) {
  const { data: boot } = trpc.chat.bootstrap.useQuery();
  const askMutation = trpc.chat.ask.useMutation();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<number | undefined>();
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const welcomed = useRef(false);

  // رسالة الترحيب من الإعدادات + سؤال افتتاحي اختياري (من رابط القسم)
  useEffect(() => {
    if (boot && !welcomed.current) {
      welcomed.current = true;
      setMessages([
        {
          id: nextId(),
          role: "bot",
          text:
            boot.settings.welcomeMessage ||
            "مرحبًا بك 👋 كيف أستطيع مساعدتك اليوم؟",
        },
      ]);
      if (initialQuestion) {
        setTimeout(() => send(initialQuestion), 400);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boot]);

  // تمرير تلقائي لآخر رسالة
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, typing, suggestions]);

  function send(text: string) {
    const clean = text.trim();
    if (!clean || typing) return;
    setMessages((m) => [...m, { id: nextId(), role: "user", text: clean }]);
    setInput("");
    setTyping(true);
    setSuggestions([]);

    askMutation.mutate(
      { sessionId: getSessionId(), conversationId, text: clean },
      {
        onSuccess: (res) => {
          setConversationId(res.conversationId);
          setMessages((m) => [
            ...m,
            {
              id: nextId(),
              role: "bot",
              text: res.reply.text,
              imageUrl: res.reply.imageUrl,
              link: res.reply.link,
              whatsappUrl: res.reply.showWhatsapp ? res.reply.whatsappUrl : null,
              correctedQuery: res.correctedQuery,
            },
          ]);
          setSuggestions(res.suggestions);
        },
        onError: () => {
          setMessages((m) => [
            ...m,
            {
              id: nextId(),
              role: "bot",
              text: "حدث خلل مؤقت في الاتصال 🙏 حاول مرة أخرى بعد لحظات.",
            },
          ]);
        },
        onSettled: () => setTyping(false),
      },
    );
  }

  const whatsapp = boot?.settings.whatsapp;

  return (
    <div
      className={`flex flex-col bg-card overflow-hidden ${
        fullPage ? "h-full" : "h-[560px] max-h-[78dvh]"
      }`}
      dir="rtl"
    >
      {/* الترويسة */}
      <div className="flex items-center gap-3 bg-primary px-4 py-3 text-primary-foreground shrink-0">
        <span className="relative grid place-items-center w-9 h-9 rounded-full bg-accent text-accent-foreground">
          <Sparkles className="w-5 h-5" />
          <span className="absolute -bottom-0.5 -left-0.5 w-2.5 h-2.5 rounded-full bg-green-300 pulse-dot text-green-300" />
        </span>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-sm leading-tight">مساعد DXN الذكي</p>
          <p className="text-[11px] opacity-80 leading-tight">
            متصل الآن — يرد فورًا على مدار الساعة
          </p>
        </div>
        {boot && (
          <span className="text-[10px] opacity-70 latin" title="حجم قاعدة المعرفة">
            {boot.kbSize.entries}+ سؤال
          </span>
        )}
      </div>

      {/* الأزرار السريعة */}
      <div className="flex gap-1.5 overflow-x-auto px-3 py-2 border-b border-border bg-secondary/50 shrink-0">
        {QUICK_BUTTONS.map((b) => (
          <button
            key={b.label}
            onClick={() => send(b.question)}
            className="flex items-center gap-1.5 whitespace-nowrap rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground hover:bg-accent hover:text-accent-foreground hover:border-accent transition-colors cursor-pointer"
          >
            <b.icon className="w-3.5 h-3.5" />
            {b.label}
          </button>
        ))}
        {whatsapp && (
          <a
            href={`https://wa.me/${whatsapp.replace(/\D/g, "")}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 whitespace-nowrap rounded-full bg-[#25D366] px-3 py-1.5 text-xs font-bold text-white hover:brightness-95 transition cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            واتساب
          </a>
        )}
      </div>

      {/* الرسائل */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-3 py-4 space-y-3 bg-background/60"
        aria-live="polite"
      >
        {messages.map((m) => (
          <div
            key={m.id}
            className={`msg-enter flex ${m.role === "user" ? "justify-start flex-row-reverse" : "justify-start"}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed whitespace-pre-line shadow-sm ${
                m.role === "user"
                  ? "bg-primary text-primary-foreground rounded-tl-md"
                  : "bg-card border border-border text-card-foreground rounded-tr-md border-s-2 border-s-accent"
              }`}
            >
              {m.correctedQuery && (
                <p className="text-[11px] opacity-70 mb-1">
                  فهمتُ سؤالك: «{m.correctedQuery}»
                </p>
              )}
              {m.text}
              {m.imageUrl && (
                <img
                  src={m.imageUrl}
                  alt=""
                  className="mt-2 rounded-lg max-h-48 w-auto border border-border"
                  loading="lazy"
                />
              )}
              {m.link && (
                <a
                  href={m.link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 flex items-center gap-1.5 rounded-lg bg-accent/20 border border-accent/50 px-3 py-2 text-xs font-bold text-foreground hover:bg-accent/40 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  {m.link.label}
                </a>
              )}
              {m.whatsappUrl && (
                <a
                  href={m.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 flex items-center justify-center gap-1.5 rounded-lg bg-[#25D366] px-3 py-2 text-xs font-bold text-white hover:brightness-95 transition"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  تواصل عبر واتساب — سؤالك جاهز للإرسال
                </a>
              )}
            </div>
          </div>
        ))}

        {typing && (
          <div className="flex">
            <div className="bg-card border border-border rounded-2xl rounded-tr-md px-4 py-3 shadow-sm">
              <span className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="w-1.5 h-1.5 rounded-full bg-muted-foreground animate-bounce"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </span>
            </div>
          </div>
        )}

        {/* الاقتراحات الذكية */}
        {!typing && suggestions.length > 0 && (
          <div className="msg-enter flex flex-wrap gap-1.5 pt-1">
            {suggestions.map((sug, i) => (
              <button
                key={i}
                onClick={() => send(sug.question)}
                className="rounded-full border border-accent/60 bg-accent/10 px-3 py-1.5 text-xs font-medium text-foreground hover:bg-accent hover:text-accent-foreground transition-colors cursor-pointer text-start"
              >
                {sug.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* الإدخال */}
      <form
        className="flex items-center gap-2 border-t border-border bg-card p-2.5 shrink-0"
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
      >
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اكتب سؤالك هنا..."
          maxLength={500}
          className="flex-1 rounded-full border border-input bg-background px-4 py-2.5 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground"
        />
        <Button
          type="submit"
          size="icon"
          disabled={!input.trim() || typing}
          className="rounded-full w-10 h-10 bg-primary hover:bg-primary/90 shrink-0 cursor-pointer"
          aria-label="إرسال"
        >
          <Send className="w-4 h-4 -scale-x-100" />
        </Button>
      </form>
    </div>
  );
}

/** الودجت العائم — زر + لوحة منبثقة */
export function ChatWidget() {
  const [open, setOpen] = useState(false);

  return (
    <>
      {open && (
        <div className="fixed bottom-24 inset-x-3 sm:inset-x-auto sm:left-5 z-50 sm:w-[380px] rounded-2xl border border-border shadow-2xl overflow-hidden msg-enter">
          <ChatWindow />
        </div>
      )}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? "إغلاق المحادثة" : "فتح المحادثة"}
        className="fixed bottom-5 left-5 z-50 grid place-items-center w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-xl hover:scale-105 active:scale-95 transition-transform cursor-pointer"
      >
        {open ? (
          <span className="text-2xl leading-none">&times;</span>
        ) : (
          <MessageCircle className="w-6 h-6" />
        )}
        {!open && (
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-accent pulse-dot text-accent" />
        )}
      </button>
    </>
  );
}
