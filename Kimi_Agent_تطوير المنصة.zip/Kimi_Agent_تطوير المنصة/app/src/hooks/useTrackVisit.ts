/** تسجيل زيارة الصفحة مرة واحدة لكل جلسة/مسار — يغذي إحصائيات الزوار في اللوحة */
import { useEffect, useRef } from "react";
import { useLocation } from "react-router";
import { trpc } from "@/providers/trpc";
import { getSessionId } from "@/lib/session";

export function useTrackVisit() {
  const location = useLocation();
  const track = trpc.chat.trackVisit.useMutation();
  const lastPath = useRef<string | null>(null);

  useEffect(() => {
    const path = location.pathname + location.search;
    if (lastPath.current === path) return;
    lastPath.current = path;
    track.mutate({
      sessionId: getSessionId(),
      path,
      referrer: document.referrer || undefined,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname, location.search]);
}
