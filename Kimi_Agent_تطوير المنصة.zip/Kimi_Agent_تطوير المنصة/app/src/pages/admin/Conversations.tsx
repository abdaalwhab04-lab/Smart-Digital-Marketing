/** سجل المحادثات الكامل — بحث داخل الرسائل + عرض تفاصيل كل محادثة */
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Search, ChevronRight, ChevronLeft, Trash2, User, Sparkles, BookOpen, LifeBuoy } from "lucide-react";

const SOURCE_LABEL: Record<string, { label: string; icon: React.ComponentType<{ className?: string }> }> = {
  kb: { label: "قاعدة المعرفة", icon: BookOpen },
  ai: { label: "ذكاء اصطناعي", icon: Sparkles },
  fallback: { label: "تحويل للدعم", icon: LifeBuoy },
  system: { label: "نظام", icon: BookOpen },
};

export default function Conversations() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [openId, setOpenId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.admin.listConversations.useQuery({
    search: search || undefined,
    page,
    pageSize: 15,
  });
  const { data: detail } = trpc.admin.conversationMessages.useQuery(
    { id: openId! },
    { enabled: openId !== null },
  );
  const del = trpc.admin.deleteConversation.useMutation({
    onSuccess: () => {
      utils.admin.listConversations.invalidate();
      setOpenId(null);
    },
  });

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-2xl font-black">سجل المحادثات</h1>
        <div className="relative">
          <Search className="absolute start-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="ابحث داخل المحادثات…"
            className="ps-8 w-64 bg-card"
          />
        </div>
      </div>

      {isLoading ? (
        <p className="text-center text-muted-foreground py-10">جارٍ التحميل…</p>
      ) : data?.conversations.length === 0 ? (
        <p className="text-center text-muted-foreground py-10">
          لا محادثات بعد — ستظهر هنا كل محادثات الزوار مع المساعد.
        </p>
      ) : (
        <div className="rounded-2xl border border-border bg-card divide-y divide-border overflow-hidden">
          {data?.conversations.map((c) => (
            <button
              key={c.id}
              onClick={() => setOpenId(c.id)}
              className="w-full flex items-center justify-between gap-3 px-4 py-3.5 hover:bg-secondary/60 transition-colors text-start cursor-pointer"
            >
              <div className="min-w-0">
                <p className="font-bold text-sm truncate">{c.title || "محادثة بدون عنوان"}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {new Date(c.lastMessageAt).toLocaleString("ar")} · {c.messageCount} رسالة
                </p>
              </div>
              <ChevronLeft className="w-4 h-4 text-muted-foreground shrink-0" />
            </button>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="cursor-pointer">
            <ChevronRight className="w-4 h-4" /> السابق
          </Button>
          <span className="text-sm text-muted-foreground latin">{page} / {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="cursor-pointer">
            التالي <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* تفاصيل المحادثة */}
      <Sheet open={openId !== null} onOpenChange={(o) => !o && setOpenId(null)}>
        <SheetContent side="left" className="w-full sm:max-w-xl overflow-y-auto" dir="rtl">
          <SheetHeader>
            <SheetTitle className="flex items-center justify-between">
              <span>{detail?.conversation?.title || "تفاصيل المحادثة"}</span>
              {openId && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-destructive cursor-pointer"
                  onClick={() => del.mutate({ id: openId })}
                >
                  <Trash2 className="w-4 h-4" /> حذف
                </Button>
              )}
            </SheetTitle>
          </SheetHeader>
          <div className="mt-4 space-y-3 px-1 pb-6">
            {detail?.messages.map((m) => {
              const src = SOURCE_LABEL[m.source];
              return (
                <div key={m.id} className={`flex ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm whitespace-pre-line ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground rounded-tl-md"
                        : "bg-secondary text-secondary-foreground rounded-tr-md"
                    }`}
                  >
                    {m.role === "user" && (
                      <span className="flex items-center gap-1 text-[10px] opacity-70 mb-1">
                        <User className="w-3 h-3" /> الزائر
                      </span>
                    )}
                    {m.content}
                    {m.role === "bot" && src && (
                      <span className="mt-1.5 flex items-center gap-1 text-[10px] opacity-60">
                        <src.icon className="w-3 h-3" />
                        {src.label}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
            {detail && detail.messages.length === 0 && (
              <p className="text-center text-muted-foreground text-sm py-8">لا رسائل في هذه المحادثة.</p>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
