/** الإعدادات — أرقام التواصل، روابط التسجيل، الإشعارات، وسلوك المساعد */
import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Save, Loader2, MessageCircle, Link2, Mail, Bot, CheckCircle2, AlertTriangle } from "lucide-react";

const FIELDS = [
  {
    key: "whatsapp",
    label: "رقم الواتساب",
    hint: "بالصيغة الدولية بدون + أو مسافات، مثال: 218946098624 — يُستخدم في زر واتساب داخل المحادثة والموقع.",
    dir: "ltr" as const,
    icon: MessageCircle,
  },
  {
    key: "sponsorCode",
    label: "كود الراعي (Sponsor Code)",
    hint: "كود العضوية الذي يظهر للزوار عند طلب التسجيل.",
    dir: "ltr" as const,
    icon: Link2,
  },
  {
    key: "registerLink",
    label: "رابط التسجيل الرسمي",
    hint: "رابط صفحة التسجيل في موقع DXN — يُرسل للزائر عند سؤاله عن التسجيل.",
    dir: "ltr" as const,
    icon: Link2,
  },
  {
    key: "notifyEmail",
    label: "بريد الإشعارات",
    hint: "يستقبل إشعارًا عند كل تسجيل اهتمام أو استفسار جديد (يتطلب تفعيل SMTP).",
    dir: "ltr" as const,
    icon: Mail,
  },
  {
    key: "facebook",
    label: "رابط فيسبوك (اختياري)",
    hint: "يظهر في تذييل الموقع.",
    dir: "ltr" as const,
    icon: Link2,
  },
  {
    key: "instagram",
    label: "رابط إنستغرام (اختياري)",
    hint: "يظهر في تذييل الموقع.",
    dir: "ltr" as const,
    icon: Link2,
  },
] as const;

type SettingsState = Record<(typeof FIELDS)[number]["key"], string> & {
  aiFallbackEnabled: boolean;
  welcomeMessage: string;
};

export default function SettingsPage() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.admin.getSettings.useQuery();
  const [form, setForm] = useState<SettingsState | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (data && !form) {
      setForm({
        whatsapp: data.whatsapp ?? "",
        sponsorCode: data.sponsorCode ?? "",
        registerLink: data.registerLink ?? "",
        notifyEmail: data.notifyEmail ?? "",
        facebook: data.facebook ?? "",
        instagram: data.instagram ?? "",
        aiFallbackEnabled: data.aiFallbackEnabled !== "false",
        welcomeMessage: data.welcomeMessage ?? "",
      });
    }
  }, [data, form]);

  const save = trpc.admin.updateSettings.useMutation({
    onSuccess: () => {
      utils.admin.getSettings.invalidate();
      utils.chat.bootstrap.invalidate();
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    },
  });

  if (isLoading || !form) {
    return <p className="text-center text-muted-foreground py-10">جارٍ التحميل…</p>;
  }

  const smtpOn = data?.smtpConfigured === "yes";

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-2xl font-black">الإعدادات</h1>

      <section className="rounded-2xl border border-border bg-card p-5 space-y-5">
        {FIELDS.map((f) => (
          <div key={f.key} className="space-y-1.5">
            <Label htmlFor={f.key} className="flex items-center gap-1.5 font-bold text-sm">
              <f.icon className="w-4 h-4 text-primary" />
              {f.label}
            </Label>
            <Input
              id={f.key}
              dir={f.dir}
              className="bg-background latin"
              value={form[f.key]}
              onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
            />
            <p className="text-[11px] text-muted-foreground">{f.hint}</p>
          </div>
        ))}
      </section>

      <section className="rounded-2xl border border-border bg-card p-5 space-y-5">
        <div className="flex items-center justify-between gap-4">
          <div>
            <Label className="flex items-center gap-1.5 font-bold text-sm">
              <Bot className="w-4 h-4 text-primary" />
              الرد بالذكاء الاصطناعي عند عدم وجود إجابة
            </Label>
            <p className="text-[11px] text-muted-foreground mt-1">
              عند إيقافه يحوَّل الزائر مباشرة إلى الدعم عبر واتساب بدل توليد رد آلي.
            </p>
          </div>
          <Switch
            checked={form.aiFallbackEnabled}
            onCheckedChange={(v) => setForm({ ...form, aiFallbackEnabled: v })}
            aria-label="تفعيل رد الذكاء الاصطناعي"
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="welcomeMessage" className="font-bold text-sm">
            رسالة الترحيب الأولى
          </Label>
          <Textarea
            id="welcomeMessage"
            rows={3}
            className="bg-background"
            value={form.welcomeMessage}
            onChange={(e) => setForm({ ...form, welcomeMessage: e.target.value })}
          />
          <p className="text-[11px] text-muted-foreground">
            أول رسالة يراها الزائر عند فتح المحادثة.
          </p>
        </div>
      </section>

      <section className="rounded-2xl border border-border bg-card p-5 space-y-3">
        <h2 className="font-bold text-sm flex items-center gap-1.5">
          <Mail className="w-4 h-4 text-primary" />
          حالة بريد الإشعارات (SMTP)
        </h2>
        {smtpOn ? (
          <Badge className="bg-primary gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> مفعّل — ستصل الإشعارات إلى بريدك
          </Badge>
        ) : (
          <div className="space-y-1.5">
            <Badge variant="secondary" className="gap-1">
              <AlertTriangle className="w-3.5 h-3.5" /> غير مفعّل حاليًا
            </Badge>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              كل الطلبات محفوظة في «صندوق البريد» داخل اللوحة وتعمل دون SMTP. لتفعيل الإرسال
              البريدي أضف متغير البيئة <span className="latin font-semibold">SMTP_URL</span> بصيغة
              <span className="latin" dir="ltr"> smtp://user:pass@host:port </span>
              في إعدادات النشر ثم أعد نشر الموقع.
            </p>
          </div>
        )}
      </section>

      <Button onClick={() =>
          save.mutate({
            whatsapp: form.whatsapp,
            sponsorCode: form.sponsorCode,
            registerLink: form.registerLink,
            notifyEmail: form.notifyEmail,
            facebook: form.facebook,
            instagram: form.instagram,
            aiFallbackEnabled: form.aiFallbackEnabled ? "true" : "false",
            welcomeMessage: form.welcomeMessage,
          })
        }
        disabled={save.isPending}
        className="cursor-pointer min-w-36"
      >
        {save.isPending ? (
          <Loader2 className="w-4 h-4 me-1.5 animate-spin" />
        ) : saved ? (
          <CheckCircle2 className="w-4 h-4 me-1.5" />
        ) : (
          <Save className="w-4 h-4 me-1.5" />
        )}
        {saved ? "تم الحفظ ✓" : "حفظ الإعدادات"}
      </Button>
    </div>
  );
}
