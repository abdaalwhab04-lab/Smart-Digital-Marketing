/**
 * إدارة قاعدة المعرفة — إضافة/تعديل/حذف الأقسام والأسئلة والإجابات المتعددة
 * مع الكلمات المفتاحية واختيار صورة من المكتبة وروابط وزر واتساب.
 */
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Search, ChevronRight, ChevronLeft, MessageCircle, Link2, ImageIcon, FolderPlus } from "lucide-react";

interface AnswerDraft {
  body: string;
  imageKey: string;
  linkUrl: string;
  linkLabel: string;
  showWhatsapp: boolean;
}

interface EntryDraft {
  id?: number;
  categoryId: number;
  question: string;
  keywords: string;
  isActive: boolean;
  answers: AnswerDraft[];
  /** معرفات الإجابات القائمة (للتعديل) */
  answerIds: (number | undefined)[];
}

const emptyDraft = (categoryId: number): EntryDraft => ({
  categoryId,
  question: "",
  keywords: "",
  isActive: true,
  answers: [{ body: "", imageKey: "", linkUrl: "", linkLabel: "", showWhatsapp: false }],
  answerIds: [undefined],
});

export default function Knowledge() {
  const utils = trpc.useUtils();
  const { data: cats } = trpc.admin.listCategories.useQuery();
  const [categoryId, setCategoryId] = useState<number | undefined>();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const { data, isLoading } = trpc.admin.listEntries.useQuery({
    categoryId,
    search: search || undefined,
    page,
    pageSize: 15,
  });

  const [draft, setDraft] = useState<EntryDraft | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [catDialog, setCatDialog] = useState<{ id?: number; name: string; description: string } | null>(null);

  const invalidate = () => {
    utils.admin.listEntries.invalidate();
    utils.admin.listCategories.invalidate();
  };

  const saveEntry = trpc.admin.createEntry.useMutation({ onSuccess: invalidate });
  const updateEntry = trpc.admin.updateEntry.useMutation({ onSuccess: invalidate });
  const addAnswer = trpc.admin.addAnswer.useMutation();
  const updateAnswer = trpc.admin.updateAnswer.useMutation();
  const deleteAnswerMut = trpc.admin.deleteAnswer.useMutation();
  const deleteEntry = trpc.admin.deleteEntry.useMutation({ onSuccess: invalidate });
  const createCat = trpc.admin.createCategory.useMutation({ onSuccess: invalidate });
  const updateCat = trpc.admin.updateCategory.useMutation({ onSuccess: invalidate });
  const { data: media } = trpc.admin.listMedia.useQuery();

  const saving = saveEntry.isPending || updateEntry.isPending;

  async function submitDraft() {
    if (!draft) return;
    const validAnswers = draft.answers.filter((a) => a.body.trim());
    if (!draft.question.trim() || validAnswers.length === 0) return;

    if (draft.id) {
      await updateEntry.mutateAsync({
        id: draft.id,
        categoryId: draft.categoryId,
        question: draft.question,
        keywords: draft.keywords,
        isActive: draft.isActive,
      });
      // مزامنة الإجابات: تحديث القائم وإضافة الجديد
      for (let i = 0; i < draft.answers.length; i++) {
        const a = draft.answers[i];
        const aid = draft.answerIds[i];
        if (!a.body.trim()) {
          if (aid) await deleteAnswerMut.mutateAsync({ id: aid });
          continue;
        }
        const payload = {
          body: a.body,
          imageKey: a.imageKey || null,
          linkUrl: a.linkUrl || null,
          linkLabel: a.linkLabel || null,
          showWhatsapp: a.showWhatsapp,
          sortOrder: i,
        };
        if (aid) await updateAnswer.mutateAsync({ id: aid, ...payload });
        else await addAnswer.mutateAsync({ qaId: draft.id, ...payload });
      }
      invalidate();
    } else {
      await saveEntry.mutateAsync({
        categoryId: draft.categoryId,
        question: draft.question,
        keywords: draft.keywords,
        answers: validAnswers.map((a) => ({
          body: a.body,
          imageKey: a.imageKey || null,
          linkUrl: a.linkUrl || null,
          linkLabel: a.linkLabel || null,
          showWhatsapp: a.showWhatsapp,
        })),
      });
    }
    setDraft(null);
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-2xl font-black">قاعدة المعرفة</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setCatDialog({ name: "", description: "" })}
            className="cursor-pointer"
          >
            <FolderPlus className="w-4 h-4" />
            قسم جديد
          </Button>
          <Button
            onClick={() => cats?.length && setDraft(emptyDraft(categoryId ?? cats[0].id))}
            className="bg-primary hover:bg-primary/90 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            سؤال جديد
          </Button>
        </div>
      </div>

      {/* أقسام + بحث */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => { setCategoryId(undefined); setPage(1); }}
          className={`rounded-full px-3.5 py-1.5 text-xs font-bold border transition-colors cursor-pointer ${
            !categoryId ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-secondary"
          }`}
        >
          الكل ({cats?.reduce((n, c) => n + c.entryCount, 0) ?? 0})
        </button>
        {cats?.map((c) => (
          <span key={c.id} className="group flex items-center">
            <button
              onClick={() => { setCategoryId(c.id); setPage(1); }}
              className={`rounded-full px-3.5 py-1.5 text-xs font-bold border transition-colors cursor-pointer ${
                categoryId === c.id ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-secondary"
              }`}
            >
              {c.name} ({c.entryCount})
            </button>
            <button
              aria-label={`تعديل قسم ${c.name}`}
              onClick={() => setCatDialog({ id: c.id, name: c.name, description: c.description ?? "" })}
              className="opacity-0 group-hover:opacity-100 -ms-1 p-1 text-muted-foreground hover:text-primary transition cursor-pointer"
            >
              <Pencil className="w-3 h-3" />
            </button>
          </span>
        ))}
        <div className="relative ms-auto">
          <Search className="absolute start-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="ابحث في الأسئلة…"
            className="ps-8 w-56 bg-card"
          />
        </div>
      </div>

      {/* القائمة */}
      {isLoading ? (
        <p className="text-center text-muted-foreground py-10">جارٍ التحميل…</p>
      ) : (
        <div className="space-y-2.5">
          {data?.entries.map((e) => (
            <article key={e.id} className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold">{e.question}</h3>
                    {!e.isActive && <Badge variant="secondary">موقوف</Badge>}
                    <span className="text-[10px] text-muted-foreground latin">×{e.hits} مشاهدة</span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
                    {e.answers[0]?.body}
                    {e.answers.length > 1 && (
                      <span className="text-primary font-bold"> … +{e.answers.length - 1} إجابات أخرى</span>
                    )}
                  </p>
                  {e.keywords && (
                    <p className="mt-1 text-[11px] text-muted-foreground/70 truncate">
                      الكلمات: {e.keywords}
                    </p>
                  )}
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="تعديل"
                    className="cursor-pointer"
                    onClick={() =>
                      setDraft({
                        id: e.id,
                        categoryId: e.categoryId,
                        question: e.question,
                        keywords: e.keywords,
                        isActive: e.isActive,
                        answers: e.answers.map((a) => ({
                          body: a.body,
                          imageKey: a.imageKey ?? "",
                          linkUrl: a.linkUrl ?? "",
                          linkLabel: a.linkLabel ?? "",
                          showWhatsapp: a.showWhatsapp,
                        })),
                        answerIds: e.answers.map((a) => a.id),
                      })
                    }
                  >
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="حذف"
                    className="text-destructive cursor-pointer"
                    onClick={() => setDeleteId(e.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </article>
          ))}
          {data?.entries.length === 0 && (
            <p className="text-center text-muted-foreground py-10">لا نتائج مطابقة.</p>
          )}
        </div>
      )}

      {/* ترقيم الصفحات */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="cursor-pointer">
            <ChevronRight className="w-4 h-4" /> السابق
          </Button>
          <span className="text-sm text-muted-foreground latin">
            {page} / {totalPages}
          </span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="cursor-pointer">
            التالي <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* محرر السؤال */}
      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent className="max-w-2xl max-h-[88dvh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>{draft?.id ? "تعديل السؤال" : "سؤال جديد"}</DialogTitle>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>القسم</Label>
                  <Select
                    value={String(draft.categoryId)}
                    onValueChange={(v) => setDraft({ ...draft, categoryId: Number(v) })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {cats?.map((c) => (
                        <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end gap-2 pb-1">
                  <Switch
                    checked={draft.isActive}
                    onCheckedChange={(v) => setDraft({ ...draft, isActive: v })}
                    id="entry-active"
                  />
                  <Label htmlFor="entry-active">نشط (يظهر في ردود المساعد)</Label>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>السؤال</Label>
                <Input
                  value={draft.question}
                  onChange={(e) => setDraft({ ...draft, question: e.target.value })}
                  placeholder="مثال: كيف أسجل في DXN؟"
                />
              </div>
              <div className="space-y-1.5">
                <Label>الكلمات المفتاحية والمرادفات (مفصولة بفاصلة)</Label>
                <Input
                  value={draft.keywords}
                  onChange={(e) => setDraft({ ...draft, keywords: e.target.value })}
                  placeholder="تسجيل، اشتراك، عضوية، انضمام"
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>الإجابات (تُختار إحداها عشوائيًا عند كل رد)</Label>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="cursor-pointer"
                    onClick={() =>
                      setDraft({
                        ...draft,
                        answers: [...draft.answers, { body: "", imageKey: "", linkUrl: "", linkLabel: "", showWhatsapp: false }],
                        answerIds: [...draft.answerIds, undefined],
                      })
                    }
                  >
                    <Plus className="w-3.5 h-3.5" /> إجابة أخرى
                  </Button>
                </div>
                {draft.answers.map((a, i) => (
                  <div key={i} className="rounded-xl border border-border bg-secondary/40 p-3 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-muted-foreground">إجابة {i + 1}</span>
                      {draft.answers.length > 1 && (
                        <button
                          type="button"
                          aria-label="حذف الإجابة"
                          className="text-destructive cursor-pointer"
                          onClick={() => {
                            const answers = draft.answers.filter((_, j) => j !== i);
                            const answerIds = draft.answerIds.filter((_, j) => j !== i);
                            setDraft({ ...draft, answers, answerIds });
                          }}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <Textarea
                      value={a.body}
                      onChange={(e) => {
                        const answers = [...draft.answers];
                        answers[i] = { ...a, body: e.target.value };
                        setDraft({ ...draft, answers });
                      }}
                      placeholder="نص الإجابة… (يمكن استخدام {{register}} {{whatsapp}} {{sponsor}})"
                      rows={3}
                    />
                    <div className="grid gap-2 sm:grid-cols-2">
                      <div className="flex items-center gap-1.5">
                        <Link2 className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                        <Input
                          value={a.linkUrl}
                          onChange={(e) => {
                            const answers = [...draft.answers];
                            answers[i] = { ...a, linkUrl: e.target.value };
                            setDraft({ ...draft, answers });
                          }}
                          placeholder="رابط (اختياري)"
                          className="h-8 text-xs"
                          dir="ltr"
                        />
                      </div>
                      <Input
                        value={a.linkLabel}
                        onChange={(e) => {
                          const answers = [...draft.answers];
                          answers[i] = { ...a, linkLabel: e.target.value };
                          setDraft({ ...draft, answers });
                        }}
                        placeholder="نص زر الرابط"
                        className="h-8 text-xs"
                      />
                    </div>
                    <div className="flex items-center gap-3 flex-wrap">
                      <Select
                        value={a.imageKey || "none"}
                        onValueChange={(v) => {
                          const answers = [...draft.answers];
                          answers[i] = { ...a, imageKey: v === "none" ? "" : v };
                          setDraft({ ...draft, answers });
                        }}
                      >
                        <SelectTrigger className="h-8 text-xs w-48">
                          <ImageIcon className="w-3.5 h-3.5" />
                          <SelectValue placeholder="بدون صورة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">بدون صورة</SelectItem>
                          {media?.map((m) => (
                            <SelectItem key={m.key} value={m.key}>{m.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                        <Switch
                          checked={a.showWhatsapp}
                          onCheckedChange={(v) => {
                            const answers = [...draft.answers];
                            answers[i] = { ...a, showWhatsapp: v };
                            setDraft({ ...draft, answers });
                          }}
                        />
                        <MessageCircle className="w-3.5 h-3.5" />
                        إظهار زر واتساب
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDraft(null)} className="cursor-pointer">إلغاء</Button>
            <Button
              onClick={submitDraft}
              disabled={saving || !draft?.question.trim() || !draft?.answers.some((a) => a.body.trim())}
              className="bg-primary hover:bg-primary/90 cursor-pointer"
            >
              {saving ? "جارٍ الحفظ…" : "حفظ السؤال"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* محرر القسم */}
      <Dialog open={!!catDialog} onOpenChange={(o) => !o && setCatDialog(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>{catDialog?.id ? "تعديل القسم" : "قسم جديد"}</DialogTitle>
          </DialogHeader>
          {catDialog && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>اسم القسم</Label>
                <Input value={catDialog.name} onChange={(e) => setCatDialog({ ...catDialog, name: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>الوصف</Label>
                <Input value={catDialog.description} onChange={(e) => setCatDialog({ ...catDialog, description: e.target.value })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              disabled={!catDialog?.name.trim()}
              className="bg-primary hover:bg-primary/90 cursor-pointer"
              onClick={async () => {
                if (!catDialog) return;
                if (catDialog.id) {
                  await updateCat.mutateAsync({ id: catDialog.id, name: catDialog.name, description: catDialog.description });
                } else {
                  await createCat.mutateAsync({
                    slug: `cat-${Date.now()}`,
                    name: catDialog.name,
                    description: catDialog.description,
                  });
                }
                setCatDialog(null);
              }}
            >
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تأكيد الحذف */}
      <AlertDialog open={deleteId !== null} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف السؤال نهائيًا؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيُحذف السؤال وجميع إجاباته من قاعدة المعرفة ولن يظهر في ردود المساعد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="cursor-pointer">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90 cursor-pointer"
              onClick={() => deleteId && deleteEntry.mutate({ id: deleteId })}
            >
              حذف نهائي
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
