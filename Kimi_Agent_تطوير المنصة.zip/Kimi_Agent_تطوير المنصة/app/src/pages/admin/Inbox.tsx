/** صندوق البريد الداخلي — استفسارات العملاء وإشعارات التسجيل الجديدة */
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MailOpen, Archive, Trash2, UserPlus, HelpCircle } from "lucide-react";

export default function InboxPage() {
  const [status, setStatus] = useState<string>("all");
  const [page, setPage] = useState(1);
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.admin.listInquiries.useQuery({
    status: status === "all" ? undefined : (status as "new" | "read" | "archived"),
    page,
    pageSize: 15,
  });
  const update = trpc.admin.updateInquiry.useMutation({
    onSuccess: () => utils.admin.listInquiries.invalidate(),
  });
  const del = trpc.admin.deleteInquiry.useMutation({
    onSuccess: () => utils.admin.listInquiries.invalidate(),
  });

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-2xl font-black">صندوق البريد ({data?.total ?? 0})</h1>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
          <SelectTrigger className="w-40 bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="new">جديد</SelectItem>
            <SelectItem value="read">مقروء</SelectItem>
            <SelectItem value="archived">مؤرشف</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <p className="text-xs text-muted-foreground rounded-xl border border-border bg-secondary/50 px-4 py-2.5">
        تصل هنا تلقائيًا: تسجيلات «سجّل اهتمامك» واستفسارات العملاء. ولاستقبال نسخة على بريدك
        الإلكتروني فعّل «بريد الإشعارات» من صفحة الإعدادات (يتطلب ضبط SMTP).
      </p>

      {isLoading ? (
        <p className="text-center text-muted-foreground py-10">جارٍ التحميل…</p>
      ) : data?.inquiries.length === 0 ? (
        <p className="text-center text-muted-foreground py-10">الصندوق فارغ.</p>
      ) : (
        <div className="space-y-2.5">
          {data?.inquiries.map((q) => (
            <article
              key={q.id}
              className={`rounded-xl border p-4 transition-colors ${
                q.status === "new" ? "border-accent bg-accent/5" : "border-border bg-card"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {q.type === "registration" ? (
                      <Badge className="bg-primary"><UserPlus className="w-3 h-3 ms-0 me-1" />تسجيل جديد</Badge>
                    ) : (
                      <Badge variant="secondary"><HelpCircle className="w-3 h-3 ms-0 me-1" />استفسار</Badge>
                    )}
                    <h3 className="font-bold">{q.subject}</h3>
                    {q.emailSent && <Badge variant="outline" className="text-[10px]">أُرسل بريدًا ✓</Badge>}
                  </div>
                  <p className="mt-1.5 text-sm whitespace-pre-line text-muted-foreground">{q.body}</p>
                  <p className="mt-2 text-xs text-muted-foreground">
                    {q.name}
                    {q.email && <span className="latin"> · {q.email}</span>}
                    {q.phone && <span className="latin"> · {q.phone}</span>}
                    {" · "}
                    {new Date(q.createdAt).toLocaleString("ar")}
                  </p>
                </div>
                <div className="flex gap-1 shrink-0">
                  {q.status === "new" && (
                    <Button size="icon" variant="ghost" aria-label="تعليم كمقروء" className="cursor-pointer" onClick={() => update.mutate({ id: q.id, status: "read" })}>
                      <MailOpen className="w-4 h-4" />
                    </Button>
                  )}
                  {q.status !== "archived" && (
                    <Button size="icon" variant="ghost" aria-label="أرشفة" className="cursor-pointer" onClick={() => update.mutate({ id: q.id, status: "archived" })}>
                      <Archive className="w-4 h-4" />
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" aria-label="حذف" className="text-destructive cursor-pointer" onClick={() => del.mutate({ id: q.id })}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="cursor-pointer">السابق</Button>
          <span className="text-sm text-muted-foreground latin">{page} / {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="cursor-pointer">التالي</Button>
        </div>
      )}
    </div>
  );
}
