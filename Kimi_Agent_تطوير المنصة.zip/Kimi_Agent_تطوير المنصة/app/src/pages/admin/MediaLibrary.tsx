/** مكتبة الصور — رفع الصور واستخدامها داخل إجابات المساعد الذكي */
import { useRef, useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ImagePlus, Trash2, ImageOff, Loader2 } from "lucide-react";

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} بايت`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} ك.ب`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} م.ب`;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      resolve(result.includes(",") ? result.split(",")[1] : result);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export default function MediaLibrary() {
  const utils = trpc.useUtils();
  const fileInput = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toDelete, setToDelete] = useState<number | null>(null);

  const { data: media, isLoading } = trpc.admin.listMedia.useQuery();
  const upload = trpc.admin.uploadMedia.useMutation({
    onSuccess: () => utils.admin.listMedia.invalidate(),
  });
  const del = trpc.admin.deleteMedia.useMutation({
    onSuccess: () => {
      utils.admin.listMedia.invalidate();
      setToDelete(null);
    },
  });

  const handleFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setError(null);
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        if (!file.type.startsWith("image/")) {
          setError(`«${file.name}» ليس ملف صورة — تم تخطيه.`);
          continue;
        }
        if (file.size > 9 * 1024 * 1024) {
          setError(`«${file.name}» أكبر من 9 م.ب — تم تخطيه.`);
          continue;
        }
        const contentBase64 = await fileToBase64(file);
        await upload.mutateAsync({
          name: file.name.replace(/[^\w؀-ۿ.\- ]/g, "_").slice(0, 120),
          contentBase64,
          contentType: file.type,
        });
      }
    } catch {
      setError("تعذر رفع الملف — حاول مرة أخرى.");
    } finally {
      setUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-2xl font-black">مكتبة الصور ({media?.length ?? 0})</h1>
        <Button
          onClick={() => fileInput.current?.click()}
          disabled={uploading}
          className="cursor-pointer"
        >
          {uploading ? (
            <Loader2 className="w-4 h-4 me-1.5 animate-spin" />
          ) : (
            <ImagePlus className="w-4 h-4 me-1.5" />
          )}
          {uploading ? "جارٍ الرفع…" : "رفع صورة"}
        </Button>
        <input
          ref={fileInput}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>

      <p className="text-xs text-muted-foreground rounded-xl border border-border bg-secondary/50 px-4 py-2.5">
        ارفع صور المنتجات هنا ثم اربطها بالإجابات من صفحة «قاعدة المعرفة» — ستظهر تلقائيًا داخل
        المحادثة عند عرض الإجابة.
      </p>

      {error && (
        <p className="text-sm text-destructive rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-2.5">
          {error}
        </p>
      )}

      {isLoading ? (
        <p className="text-center text-muted-foreground py-10">جارٍ التحميل…</p>
      ) : !media?.length ? (
        <div className="text-center py-14 text-muted-foreground">
          <ImageOff className="w-10 h-10 mx-auto mb-3 opacity-50" />
          <p>لا توجد صور بعد — ارفع أول صورة لمنتجاتك.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {media.map((m) => (
            <figure
              key={m.id}
              className="group relative rounded-xl border border-border bg-card overflow-hidden"
            >
              <div className="aspect-square bg-secondary/60 flex items-center justify-center">
                {m.url ? (
                  <img
                    src={m.url}
                    alt={m.name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <ImageOff className="w-8 h-8 text-muted-foreground/40" />
                )}
              </div>
              <figcaption className="p-2.5">
                <p className="text-xs font-semibold truncate" title={m.name}>
                  {m.name}
                </p>
                <p className="text-[10px] text-muted-foreground">
                  {formatSize(m.size)} · {new Date(m.createdAt).toLocaleDateString("ar")}
                </p>
              </figcaption>
              <Button
                size="icon"
                variant="destructive"
                aria-label={`حذف ${m.name}`}
                className="absolute top-2 end-2 w-8 h-8 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity cursor-pointer shadow"
                onClick={() => setToDelete(m.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </figure>
          ))}
        </div>
      )}

      <AlertDialog open={toDelete !== null} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الصورة؟</AlertDialogTitle>
            <AlertDialogDescription>
              ستُحذف الصورة نهائيًا من المكتبة. الإجابات المرتبطة بها ستعرض بدون صورة.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogCancel className="cursor-pointer">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 cursor-pointer"
              onClick={() => toDelete !== null && del.mutate({ id: toDelete })}
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
