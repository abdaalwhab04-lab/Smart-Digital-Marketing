/** إدارة العملاء المسجلين (Leads) — بحث وتصفية بالحالة وتحديثها */
import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search, Trash2, MessageCircle } from "lucide-react";

const STATUS: Record<string, { label: string; variant: "default" | "secondary" | "outline" | "destructive" }> = {
  new: { label: "جديد", variant: "default" },
  contacted: { label: "تم التواصل", variant: "secondary" },
  registered: { label: "سجّل عضوية", variant: "outline" },
  archived: { label: "مؤرشف", variant: "destructive" },
};

export default function Customers() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [page, setPage] = useState(1);
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.admin.listCustomers.useQuery({
    search: search || undefined,
    status: status === "all" ? undefined : (status as "new" | "contacted" | "registered" | "archived"),
    page,
    pageSize: 15,
  });
  const update = trpc.admin.updateCustomer.useMutation({
    onSuccess: () => utils.admin.listCustomers.invalidate(),
  });
  const del = trpc.admin.deleteCustomer.useMutation({
    onSuccess: () => utils.admin.listCustomers.invalidate(),
  });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h1 className="text-2xl font-black">العملاء ({data?.total ?? 0})</h1>
        <div className="flex gap-2">
          <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
            <SelectTrigger className="w-36 bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل الحالات</SelectItem>
              {Object.entries(STATUS).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="relative">
            <Search className="absolute start-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="ابحث بالاسم أو الهاتف…"
              className="ps-8 w-56 bg-card"
            />
          </div>
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-start">الاسم</TableHead>
              <TableHead className="text-start">الهاتف</TableHead>
              <TableHead className="text-start hidden md:table-cell">البريد</TableHead>
              <TableHead className="text-start hidden sm:table-cell">المدينة / الدولة</TableHead>
              <TableHead className="text-start hidden lg:table-cell">الاهتمام</TableHead>
              <TableHead className="text-start">الحالة</TableHead>
              <TableHead className="text-start">إجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">جارٍ التحميل…</TableCell></TableRow>
            ) : data?.customers.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">لا عملاء بعد — نموذج «سجّل اهتمامك» في الصفحة الرئيسية يغذي هذه القائمة.</TableCell></TableRow>
            ) : (
              data?.customers.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-bold">{c.name}</TableCell>
                  <TableCell>
                    <a
                      href={`https://wa.me/${c.phone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 text-primary hover:underline latin"
                      dir="ltr"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      {c.phone}
                    </a>
                  </TableCell>
                  <TableCell className="hidden md:table-cell latin" dir="ltr">{c.email || "—"}</TableCell>
                  <TableCell className="hidden sm:table-cell">{[c.city, c.country].filter(Boolean).join(" / ") || "—"}</TableCell>
                  <TableCell className="hidden lg:table-cell text-sm">{c.interest || "—"}</TableCell>
                  <TableCell>
                    <Select
                      value={c.status}
                      onValueChange={(v) => update.mutate({ id: c.id, status: v as typeof c.status })}
                    >
                      <SelectTrigger className="h-8 w-32">
                        <Badge variant={STATUS[c.status].variant}>{STATUS[c.status].label}</Badge>
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(STATUS).map(([k, v]) => (
                          <SelectItem key={k} value={k}>{v.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Button
                      size="icon"
                      variant="ghost"
                      aria-label="حذف العميل"
                      className="text-destructive cursor-pointer"
                      onClick={() => del.mutate({ id: c.id })}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {data && data.total > data.pageSize && (
        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="cursor-pointer">السابق</Button>
          <span className="text-sm text-muted-foreground latin">{page} / {Math.ceil(data.total / data.pageSize)}</span>
          <Button variant="outline" size="sm" disabled={page >= Math.ceil(data.total / data.pageSize)} onClick={() => setPage((p) => p + 1)} className="cursor-pointer">التالي</Button>
        </div>
      )}
    </div>
  );
}
