/** نظرة عامة — بطاقات الإحصائيات + رسم بياني + أكثر الأسئلة والكلمات تكرارًا */
import { trpc } from "@/providers/trpc";
import {
  Eye,
  Users,
  MessagesSquare,
  MessageSquareText,
  UserCheck,
  Inbox,
  Sparkles,
  BookOpen,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function Dashboard() {
  const { data: stats, isLoading } = trpc.admin.statsOverview.useQuery();
  const { data: topQ } = trpc.admin.topQuestions.useQuery({ limit: 8 });
  const { data: topK } = trpc.admin.topKeywords.useQuery({ limit: 15 });

  if (isLoading || !stats) {
    return <p className="text-muted-foreground p-8 text-center">جارٍ تحميل الإحصائيات…</p>;
  }

  const cards = [
    { icon: Eye, label: "إجمالي الزيارات", value: stats.totalVisits },
    { icon: Users, label: "زوار فريدون", value: stats.uniqueVisitors },
    { icon: MessagesSquare, label: "المحادثات", value: stats.totalConversations },
    { icon: MessageSquareText, label: "الرسائل", value: stats.totalMessages },
    { icon: UserCheck, label: "العملاء المسجلون", value: stats.totalCustomers },
    { icon: Inbox, label: "استفسارات جديدة", value: stats.newInquiries },
    { icon: Sparkles, label: "ردود الذكاء الاصطناعي", value: stats.aiReplies },
    { icon: BookOpen, label: "أسئلة قاعدة المعرفة", value: stats.totalQa },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-black">نظرة عامة</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">{c.label}</p>
              <c.icon className="w-4 h-4 text-primary" />
            </div>
            <p className="mt-2 text-3xl font-black latin">{c.value.toLocaleString("en")}</p>
          </div>
        ))}
      </div>

      {/* الرسم البياني — آخر 14 يومًا */}
      <div className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-bold mb-4">النشاط — آخر 14 يومًا</h2>
        <div className="h-64" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={stats.daily} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
              <defs>
                <linearGradient id="gVisits" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(152 56% 35%)" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="hsl(152 56% 35%)" stopOpacity={0.02} />
                </linearGradient>
                <linearGradient id="gConvs" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(158 54% 58%)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(158 54% 58%)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(40 16% 85%)" />
              <XAxis dataKey="day" tick={{ fontSize: 10 }} tickFormatter={(d: string) => d.slice(5)} />
              <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{ fontFamily: "Tajawal", direction: "rtl", fontSize: 12 }}
                labelFormatter={(d) => `اليوم: ${d}`}
              />
              <Area type="monotone" dataKey="visits" name="الزيارات" stroke="hsl(152 56% 35%)" fill="url(#gVisits)" strokeWidth={2} />
              <Area type="monotone" dataKey="conversations" name="المحادثات" stroke="hsl(158 54% 50%)" fill="url(#gConvs)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* أكثر الأسئلة تكرارًا */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="font-bold mb-3">أكثر الأسئلة تكرارًا</h2>
          {topQ && topQ.length > 0 ? (
            <ul className="space-y-2">
              {topQ.map((q, i) => (
                <li key={q.id} className="flex items-center gap-3 text-sm">
                  <span className="w-6 h-6 shrink-0 grid place-items-center rounded-full bg-secondary text-xs font-black latin">
                    {i + 1}
                  </span>
                  <span className="flex-1 truncate">{q.question}</span>
                  <span className="text-xs text-muted-foreground shrink-0">
                    {q.category} · <b className="latin">{q.hits}</b>
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">لا بيانات بعد — ستظهر مع أول أسئلة الزوار.</p>
          )}
        </div>

        {/* أكثر الكلمات استخدامًا */}
        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="font-bold mb-3">أكثر الكلمات المفتاحية استخدامًا</h2>
          {topK && topK.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {topK.map((k) => {
                const max = topK[0].count || 1;
                const scale = 0.75 + (k.count / max) * 0.6;
                return (
                  <span
                    key={k.id}
                    className="rounded-full bg-secondary px-3 py-1 font-bold text-primary"
                    style={{ fontSize: `${scale}rem` }}
                    title={`${k.count} مرة`}
                  >
                    {k.keyword}
                    <span className="text-muted-foreground text-xs font-normal latin"> ×{k.count}</span>
                  </span>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">لا بيانات بعد.</p>
          )}
        </div>
      </div>
    </div>
  );
}
