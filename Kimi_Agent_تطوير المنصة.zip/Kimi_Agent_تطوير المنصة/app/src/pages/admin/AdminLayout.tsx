/**
 * هيكل لوحة التحكم — شريط جانبي داكن أخضر-فحمي بنمط غرفة العمليات.
 * محمية: تتطلب تسجيل دخول Kimi + دور admin (المالك يحصل عليه تلقائيًا).
 */
import { NavLink, Outlet } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard,
  BookOpen,
  MessagesSquare,
  Users,
  Inbox,
  Images,
  Settings,
  LogOut,
  Leaf,
  ExternalLink,
  ShieldAlert,
} from "lucide-react";
import { AuthLayoutSkeleton } from "@/components/AuthLayoutSkeleton";
import { Button } from "@/components/ui/button";

const MENU = [
  { to: "/admin", label: "نظرة عامة", icon: LayoutDashboard, end: true },
  { to: "/admin/knowledge", label: "قاعدة المعرفة", icon: BookOpen },
  { to: "/admin/conversations", label: "المحادثات", icon: MessagesSquare },
  { to: "/admin/customers", label: "العملاء", icon: Users },
  { to: "/admin/inbox", label: "صندوق البريد", icon: Inbox },
  { to: "/admin/media", label: "مكتبة الصور", icon: Images },
  { to: "/admin/settings", label: "الإعدادات", icon: Settings },
];

export default function AdminLayout() {
  const { user, isLoading, logout } = useAuth({ redirectOnUnauthenticated: true });

  if (isLoading) return <AuthLayoutSkeleton />;
  if (!user) return null;

  if (user.role !== "admin") {
    return (
      <div className="min-h-dvh grid place-items-center bg-background p-6">
        <div className="max-w-md text-center rounded-2xl border border-border bg-card p-10">
          <ShieldAlert className="w-12 h-12 mx-auto text-destructive" />
          <h1 className="mt-4 text-xl font-black">لا تملك صلاحية الإدارة</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            لوحة التحكم مخصصة لمالك المنصة فقط. إذا كنت المالك، سجّل الدخول
            بحساب Kimi المالك للموقع.
          </p>
          <Button onClick={logout} variant="outline" className="mt-6 cursor-pointer">
            تسجيل الخروج
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh flex bg-background" dir="rtl">
      {/* الشريط الجانبي */}
      <aside className="w-60 shrink-0 bg-sidebar-background text-sidebar-foreground flex-col sticky top-0 h-dvh hidden md:flex">
        <div className="flex items-center gap-2 px-5 py-5 border-b border-sidebar-border">
          <span className="grid place-items-center w-8 h-8 rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
            <Leaf className="w-4 h-4" />
          </span>
          <div>
            <p className="font-black text-sm leading-tight">لوحة التحكم</p>
            <p className="text-[10px] opacity-60">منصة DXN الذكية</p>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1" aria-label="قائمة الإدارة">
          {MENU.map((m) => (
            <NavLink
              key={m.to}
              to={m.to}
              end={m.end}
              className={({ isActive }) =>
                `flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-primary font-bold"
                    : "hover:bg-sidebar-accent/60"
                }`
              }
            >
              <m.icon className="w-4 h-4 shrink-0" />
              {m.label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-sidebar-border p-3 space-y-1">
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent/60 transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
            معاينة الموقع
          </a>
          <button
            onClick={logout}
            className="w-full flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent/60 transition-colors cursor-pointer text-start"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </button>
          <p className="px-3 pt-1 text-[10px] opacity-50 truncate">{user.name || user.email}</p>
        </div>
      </aside>

      {/* قائمة الجوال العلوية */}
      <div className="flex-1 min-w-0 flex flex-col">
        <MobileNav />
        <main className="flex-1 p-4 sm:p-6 max-w-[1400px] w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function MobileNav() {
  return (
    <div className="md:hidden sticky top-0 z-30 bg-sidebar-background text-sidebar-foreground border-b border-sidebar-border">
      <div className="flex items-center gap-1.5 overflow-x-auto px-3 py-2.5">
        {MENU.map((m) => (
          <NavLink
            key={m.to}
            to={m.to}
            end={m.end}
            className={({ isActive }) =>
              `flex items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                isActive ? "bg-sidebar-primary text-sidebar-primary-foreground" : "hover:bg-sidebar-accent/60"
              }`
            }
          >
            <m.icon className="w-3.5 h-3.5" />
            {m.label}
          </NavLink>
        ))}
      </div>
    </div>
  );
}
