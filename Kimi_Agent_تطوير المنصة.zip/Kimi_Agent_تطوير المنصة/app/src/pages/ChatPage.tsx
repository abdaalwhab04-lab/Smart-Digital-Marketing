/** صفحة المحادثة الكاملة — تجربة شبيهة بمسنجر الأعمال */
import { useSearchParams } from "react-router";
import { SiteHeader, SiteFooter } from "@/components/site/Layout";
import { ChatWindow } from "@/components/chat/ChatWindow";
import { trpc } from "@/providers/trpc";
import { useTrackVisit } from "@/hooks/useTrackVisit";

export default function ChatPage() {
  const [params] = useSearchParams();
  const cat = params.get("cat");
  const { data: boot } = trpc.chat.bootstrap.useQuery();
  useTrackVisit();

  const initialQuestion = cat ? `أخبرني عن ${cat}` : undefined;

  return (
    <div className="min-h-dvh flex flex-col">
      <SiteHeader />
      <main className="flex-1 mx-auto w-full max-w-3xl px-3 sm:px-4 py-4 sm:py-6 flex flex-col">
        <div
          className="flex-1 min-h-[70dvh] rounded-2xl border border-border shadow-lg overflow-hidden flex flex-col"
          key={cat ?? "default"}
        >
          <ChatWindow fullPage initialQuestion={initialQuestion} />
        </div>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          المساعد يجيب من قاعدة معرفة بـ {boot?.kbSize.entries ?? "550"}+ سؤالًا
          ويدعم الذكاء الاصطناعي للأسئلة الجديدة — وللطلب المباشر استخدم زر واتساب.
        </p>
      </main>
      <SiteFooter />
    </div>
  );
}
