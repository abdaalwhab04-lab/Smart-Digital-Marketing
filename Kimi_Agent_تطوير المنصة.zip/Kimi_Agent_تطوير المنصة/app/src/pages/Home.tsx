/** الصفحة الرئيسية — منصة chat-first: المساعد الذكي في قلب الواجهة */
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { SiteHeader, SiteFooter } from "@/components/site/Layout";
import { ChatWindow, ChatWidget } from "@/components/chat/ChatWindow";
import { LeadForm } from "@/components/LeadForm";
import { useTrackVisit } from "@/hooks/useTrackVisit";
import {
  MessageCircle,
  Package,
  UserPlus,
  TrendingUp,
  Truck,
  GraduationCap,
  Network,
  ShieldQuestion,
  Headset,
  Building2,
  Zap,
  Clock,
  Database,
  Coffee,
  Leaf,
  BadgeCheck,
  ArrowDown,
} from "lucide-react";

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Building2,
  Package,
  UserPlus,
  TrendingUp,
  Truck,
  GraduationCap,
  Network,
  ShieldQuestion,
  Headset,
};

const FEATURED_PRODUCTS = [
  {
    icon: Coffee,
    name: "قهوة لينجزي 3 في 1",
    desc: "قهوة فورية فاخرة بخلاصة فطر الجانوديرما — المنتج الأشهر في DXN عالميًا.",
    tag: "الأكثر مبيعًا",
  },
  {
    icon: Leaf,
    name: "سبيرولينا",
    desc: "طحلب أخضر يُعد من أغنى الأغذية الطبيعية بالبروتين والفيتامينات.",
    tag: "تغذية يومية",
  },
  {
    icon: BadgeCheck,
    name: "ريشي جانو RG",
    desc: "خلاصة الجانوديرما المركزة لدعم المناعة والتوازن الداخلي.",
    tag: "الأعلى نقاطًا",
  },
];

export default function Home() {
  const { data: boot } = trpc.chat.bootstrap.useQuery();
  useTrackVisit();

  return (
    <div className="min-h-dvh flex flex-col">
      <SiteHeader />

      {/* ============ البطل: عنوان + محادثة حية ============ */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        {/* زخرفة دوائر خفيفة */}
        <div aria-hidden className="pointer-events-none absolute -top-32 -left-32 w-96 h-96 rounded-full bg-accent/15 blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute bottom-0 right-0 w-72 h-72 rounded-full bg-gold/10 blur-3xl" style={{ background: "hsl(var(--gold) / 0.12)" }} />

        <div className="relative mx-auto max-w-6xl px-4 py-12 sm:py-16 grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-accent/15 border border-accent/30 px-3 py-1 text-xs font-bold" style={{ color: "hsl(var(--accent))" }}>
              <span className="w-2 h-2 rounded-full pulse-dot" style={{ background: "hsl(var(--accent))", color: "hsl(var(--accent))" }} />
              مساعد ذكاء اصطناعي متصل الآن
            </p>
            <h1 className="mt-4 text-4xl sm:text-5xl font-black leading-[1.25]">
              منصتك الذكية
              <br />
              للتسويق الشبكي
              <span className="block mt-1" style={{ color: "hsl(var(--accent))" }}>
                مع منتجات DXN
              </span>
            </h1>
            <p className="mt-4 text-base sm:text-lg opacity-85 leading-relaxed max-w-lg">
              اسأل عن أي منتج، التسجيل، الأرباح، الشحن أو التدريب — المساعد الذكي
              يجيبك فورًا من قاعدة معرفة بمئات الأسئلة، ويحوّلك لفريقنا عند الحاجة.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                to="/chat"
                className="inline-flex items-center gap-2 rounded-full px-6 py-3 font-bold text-sm transition-transform hover:scale-[1.03] active:scale-95"
                style={{ background: "hsl(var(--accent))", color: "hsl(var(--accent-foreground))" }}
              >
                <MessageCircle className="w-4 h-4" />
                ابدأ المحادثة الآن
              </Link>
              <a
                href="#register"
                className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/40 px-6 py-3 font-bold text-sm hover:bg-primary-foreground/10 transition-colors"
              >
                سجّل اهتمامك
              </a>
            </div>

            {/* شريط أرقام */}
            <div className="mt-10 grid grid-cols-3 gap-4 max-w-md">
              {[
                { icon: Database, num: boot ? `${boot.kbSize.entries}+` : "550+", label: "سؤال وجواب" },
                { icon: Zap, num: "فوري", label: "سرعة الرد" },
                { icon: Clock, num: "24/7", label: "متاح دائمًا" },
              ].map((s) => (
                <div key={s.label} className="rounded-xl bg-primary-foreground/8 border border-primary-foreground/15 p-3 text-center backdrop-blur-sm">
                  <s.icon className="w-4 h-4 mx-auto opacity-80" />
                  <p className="mt-1 font-black text-lg leading-tight latin">{s.num}</p>
                  <p className="text-[11px] opacity-70">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* المحادثة الحية داخل البطل (سطح المكتب) */}
          <div className="hidden lg:block rounded-2xl border border-primary-foreground/20 shadow-2xl overflow-hidden msg-enter">
            <ChatWindow />
          </div>
        </div>

        <a href="#categories" aria-label="انتقل للأسفل" className="absolute bottom-3 left-1/2 -translate-x-1/2 opacity-60 hover:opacity-100 transition-opacity">
          <ArrowDown className="w-5 h-5 animate-bounce" />
        </a>
      </section>

      {/* ============ أقسام قاعدة المعرفة ============ */}
      <section id="categories" className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="text-2xl sm:text-3xl font-black text-center">عن ماذا تريد أن تسأل؟</h2>
        <p className="mt-2 text-center text-muted-foreground">
          تسعة أقسام تغطي كل ما تحتاجه — اضغط أي قسم ليسأل المساعد عنه مباشرة
        </p>
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {(boot?.categories ?? []).map((c) => {
            const Icon = ICONS[c.icon ?? ""] ?? Package;
            return (
              <Link
                key={c.id}
                to={`/chat?cat=${encodeURIComponent(c.name)}`}
                className="group rounded-2xl border border-border bg-card p-4 text-center hover:border-accent hover:-translate-y-0.5 transition-all"
              >
                <span className="mx-auto grid place-items-center w-11 h-11 rounded-xl bg-secondary text-primary group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                  <Icon className="w-5 h-5" />
                </span>
                <p className="mt-2.5 text-sm font-bold">{c.name}</p>
              </Link>
            );
          })}
          <a
            href="#register"
            className="group rounded-2xl border-2 border-dashed border-accent/60 bg-accent/5 p-4 text-center hover:bg-accent/15 transition-colors"
          >
            <span className="mx-auto grid place-items-center w-11 h-11 rounded-xl bg-accent text-accent-foreground">
              <MessageCircle className="w-5 h-5" />
            </span>
            <p className="mt-2.5 text-sm font-bold">سؤال آخر؟ اسألنا</p>
          </a>
        </div>
      </section>

      {/* ============ المنتجات المميزة ============ */}
      <section id="products" className="bg-secondary/50 border-y border-border">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <div className="flex items-end justify-between gap-4 flex-wrap">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black">منتجات يعاد شراؤها كل شهر</h2>
              <p className="mt-2 text-muted-foreground max-w-xl">
                قوة مشروع DXN أن منتجاته استهلاكية يومية: قهوة ومكملات وعناية شخصية — الطلب يتكرر والدخل يتراكم.
              </p>
            </div>
            <Link to="/chat" className="text-sm font-bold text-primary hover:underline underline-offset-4">
              اسأل المساعد عن أي منتج ←
            </Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {FEATURED_PRODUCTS.map((p) => (
              <article key={p.name} className="rounded-2xl border border-border bg-card p-6 hover:shadow-lg hover:-translate-y-1 transition-all">
                <div className="flex items-center justify-between">
                  <span className="grid place-items-center w-12 h-12 rounded-xl bg-primary text-primary-foreground">
                    <p.icon className="w-6 h-6" />
                  </span>
                  <span className="rounded-full bg-accent/20 px-2.5 py-1 text-[11px] font-bold" style={{ color: "hsl(var(--accent-foreground))" }}>
                    {p.tag}
                  </span>
                </div>
                <h3 className="mt-4 font-black text-lg">{p.name}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ============ فرصة العمل ============ */}
      <section id="opportunity" className="mx-auto max-w-6xl px-4 py-14">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black">ثلاثة مصادر دخل من مشروع واحد</h2>
            <div className="mt-6 space-y-4">
              {[
                {
                  n: "01",
                  title: "ربح التجزئة المباشر",
                  desc: "تشتري بسعر العضوية وتبيع بسعر التجزئة — فرق يصل إلى 25% في جيبك فورًا.",
                },
                {
                  n: "02",
                  title: "عمولات الشبكة الشهرية",
                  desc: "نسبة من نقاط مبيعات فريقك كل شهر — تتراكم مع إعادة الشراء المتكررة.",
                },
                {
                  n: "03",
                  title: "المكافآت القيادية",
                  desc: "رتب تصاعدية تفتح مكافآت نقدية ورحلات وحوافز عند بلوغ مستويات القيادة.",
                },
              ].map((s) => (
                <div key={s.n} className="flex gap-4 rounded-2xl border border-border bg-card p-5">
                  <span className="font-black text-2xl latin" style={{ color: "hsl(var(--accent))" }}>{s.n}</span>
                  <div>
                    <h3 className="font-bold">{s.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl bg-primary text-primary-foreground p-8 sm:p-10">
            <h3 className="text-xl font-black">لماذا يختار آلاف المسوقين DXN؟</h3>
            <ul className="mt-5 space-y-3 text-sm leading-relaxed">
              {[
                "شركة ماليزية مدرجة في البورصة، تعمل منذ 1993 في أكثر من 180 دولة",
                "منتجات طبيعية بشهادات GMP وISO وحلال — تصنعها الشركة من الزراعة للتغليف",
                "تسجيل مجاني مدى الحياة — لا رسوم انضمام ولا التزام شراء إجباري",
                "تدريب عربي كامل معنا من الصفر حتى أول عمولة",
                "كل أدواتك من هاتفك: التسجيل، الطلب، والمتابعة",
              ].map((t) => (
                <li key={t} className="flex gap-2.5">
                  <BadgeCheck className="w-5 h-5 shrink-0" style={{ color: "hsl(var(--accent))" }} />
                  <span className="opacity-90">{t}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/chat"
              className="mt-6 inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition-transform hover:scale-[1.03]"
              style={{ background: "hsl(var(--accent))", color: "hsl(var(--accent-foreground))" }}
            >
              اسأل عن خطة الأرباح كاملة
            </Link>
          </div>
        </div>
      </section>

      {/* ============ نموذج التسجيل ============ */}
      <section id="register" className="mx-auto max-w-3xl px-4 py-14 w-full">
        <h2 className="text-2xl sm:text-3xl font-black text-center">سجّل اهتمامك — وسنتواصل معك</h2>
        <p className="mt-2 text-center text-muted-foreground">
          اترك بياناتك وسيتصل بك فريقنا ليجيب عن أسئلتك ويساعدك في التسجيل المجاني
        </p>
        <div className="mt-8">
          <LeadForm />
        </div>
      </section>

      <SiteFooter />
      <ChatWidget />
    </div>
  );
}
