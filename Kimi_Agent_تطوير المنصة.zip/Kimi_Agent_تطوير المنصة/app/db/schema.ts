/**
 * مخطط قاعدة البيانات — منصة التسويق الشبكي الذكية
 *
 * الجداول:
 * - users            حسابات الدخول (Kimi OAuth) — المالك admin تلقائيًا
 * - categories       أقسام قاعدة المعرفة (الشركة، المنتجات، التسجيل...)
 * - qaEntries        الأسئلة (كل سؤال ينتمي لقسم ويملك كلمات مفتاحية)
 * - qaAnswers        إجابات متعددة لكل سؤال (تُختار عشوائيًا) + صورة/رابط/واتساب
 * - visits           زيارات الصفحات (لإحصائيات الزوار)
 * - conversations    جلسات المحادثة مع المساعد
 * - messages         رسائل المحادثات (user/bot) مع السؤال المطابَق ومصدر الرد
 * - customers        بيانات العملاء المُجمعة من النماذج (Leads)
 * - inquiries        صندوق الاستفسارات وإشعارات التسجيل (البريد الداخلي)
 * - settings         إعدادات المنصة (واتساب، روابط، بريد الإشعارات...)
 * - mediaFiles       سجل الصور المرفوعة في مخزن الكائنات
 * - keywordStats     عداد الكلمات المفتاحية الأكثر استخدامًا
 */
import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/* ---------------- أقسام قاعدة المعرفة ---------------- */
export const categories = mysqlTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  description: varchar("description", { length: 500 }),
  icon: varchar("icon", { length: 60 }),
  sortOrder: int("sortOrder").default(0).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Category = typeof categories.$inferSelect;

/* ---------------- الأسئلة ---------------- */
export const qaEntries = mysqlTable(
  "qa_entries",
  {
    id: serial("id").primaryKey(),
    categoryId: bigint("categoryId", { mode: "number", unsigned: true }).notNull(),
    question: text("question").notNull(),
    /** كلمات مفتاحية ومرادفات مفصولة بفواصل */
    keywords: text("keywords").notNull(),
    hits: int("hits").default(0).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => [index("qa_cat_idx").on(t.categoryId)],
);

export type QaEntry = typeof qaEntries.$inferSelect;

/* ---------------- الإجابات (عدة إجابات لكل سؤال) ---------------- */
export const qaAnswers = mysqlTable(
  "qa_answers",
  {
    id: serial("id").primaryKey(),
    qaId: bigint("qaId", { mode: "number", unsigned: true }).notNull(),
    body: text("body").notNull(),
    /** مفتاح صورة في مخزن الكائنات (اختياري) */
    imageKey: varchar("imageKey", { length: 255 }),
    linkUrl: varchar("linkUrl", { length: 500 }),
    linkLabel: varchar("linkLabel", { length: 120 }),
    showWhatsapp: boolean("showWhatsapp").default(false).notNull(),
    sortOrder: int("sortOrder").default(0).notNull(),
  },
  (t) => [index("ans_qa_idx").on(t.qaId)],
);

export type QaAnswer = typeof qaAnswers.$inferSelect;

/* ---------------- الزيارات ---------------- */
export const visits = mysqlTable(
  "visits",
  {
    id: serial("id").primaryKey(),
    sessionId: varchar("sessionId", { length: 64 }).notNull(),
    path: varchar("path", { length: 255 }).default("/"),
    referrer: varchar("referrer", { length: 500 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [
    index("visit_sess_idx").on(t.sessionId),
    index("visit_created_idx").on(t.createdAt),
  ],
);

/* ---------------- المحادثات ---------------- */
export const conversations = mysqlTable(
  "conversations",
  {
    id: serial("id").primaryKey(),
    sessionId: varchar("sessionId", { length: 64 }).notNull(),
    title: varchar("title", { length: 255 }),
    messageCount: int("messageCount").default(0).notNull(),
    startedAt: timestamp("startedAt").defaultNow().notNull(),
    lastMessageAt: timestamp("lastMessageAt").defaultNow().notNull(),
  },
  (t) => [index("conv_sess_idx").on(t.sessionId)],
);

export type Conversation = typeof conversations.$inferSelect;

/* ---------------- الرسائل ---------------- */
export const messages = mysqlTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    conversationId: bigint("conversationId", { mode: "number", unsigned: true }).notNull(),
    role: mysqlEnum("role", ["user", "bot"]).notNull(),
    content: text("content").notNull(),
    matchedQaId: bigint("matchedQaId", { mode: "number", unsigned: true }),
    source: mysqlEnum("source", ["kb", "ai", "fallback", "system"])
      .default("kb")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => [
    index("msg_conv_idx").on(t.conversationId),
    index("msg_qa_idx").on(t.matchedQaId),
  ],
);

export type Message = typeof messages.$inferSelect;

/* ---------------- العملاء (Leads) ---------------- */
export const customers = mysqlTable("customers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  email: varchar("email", { length: 320 }),
  city: varchar("city", { length: 120 }),
  country: varchar("country", { length: 120 }),
  interest: varchar("interest", { length: 120 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["new", "contacted", "registered", "archived"])
    .default("new")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;

/* ---------------- صندوق الاستفسارات والإشعارات ---------------- */
export const inquiries = mysqlTable("inquiries", {
  id: serial("id").primaryKey(),
  type: mysqlEnum("type", ["inquiry", "registration"]).notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 40 }),
  subject: varchar("subject", { length: 255 }),
  body: text("body").notNull(),
  status: mysqlEnum("status", ["new", "read", "archived"]).default("new").notNull(),
  emailSent: boolean("emailSent").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Inquiry = typeof inquiries.$inferSelect;

/* ---------------- الإعدادات ---------------- */
export const settings = mysqlTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 80 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

/* ---------------- مكتبة الصور ---------------- */
export const mediaFiles = mysqlTable("media_files", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  size: int("size").default(0).notNull(),
  contentType: varchar("contentType", { length: 120 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MediaFile = typeof mediaFiles.$inferSelect;

/* ---------------- إحصائيات الكلمات المفتاحية ---------------- */
export const keywordStats = mysqlTable("keyword_stats", {
  id: serial("id").primaryKey(),
  keyword: varchar("keyword", { length: 120 }).notNull().unique(),
  count: int("count").default(0).notNull(),
});
