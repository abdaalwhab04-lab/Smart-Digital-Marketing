import { relations } from "drizzle-orm";
import {
  categories,
  qaEntries,
  qaAnswers,
  conversations,
  messages,
} from "./schema";

export const categoriesRelations = relations(categories, ({ many }) => ({
  entries: many(qaEntries),
}));

export const qaEntriesRelations = relations(qaEntries, ({ one, many }) => ({
  category: one(categories, {
    fields: [qaEntries.categoryId],
    references: [categories.id],
  }),
  answers: many(qaAnswers),
}));

export const qaAnswersRelations = relations(qaAnswers, ({ one }) => ({
  entry: one(qaEntries, {
    fields: [qaAnswers.qaId],
    references: [qaEntries.id],
  }),
}));

export const conversationsRelations = relations(conversations, ({ many }) => ({
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));
