/**
 * زرع قاعدة المعرفة والإعدادات الافتراضية.
 * التشغيل: npx tsx db/seed.ts
 * السكربت آمن للتكرار: يتوقف إذا كانت الأقسام موجودة أصلًا.
 */
import "dotenv/config";
import { count } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import { categories, qaEntries, qaAnswers, settings } from "./schema";
import { PRODUCT_ENTRIES } from "./seed-data";
import {
  COMPANY_ENTRIES,
  REGISTRATION_ENTRIES,
  PROFITS_ENTRIES,
  SHIPPING_ENTRIES,
  TRAINING_ENTRIES,
  MLM_ENTRIES,
  OBJECTION_ENTRIES,
  SUPPORT_ENTRIES,
} from "./seed-banks";

const CATEGORIES = [
  { slug: "company", name: "الشركة", description: "كل ما يخص شركة DXN وتاريخها ومصداقيتها", icon: "Building2" },
  { slug: "products", name: "المنتجات", description: "معلومات منتجات DXN: الفوائد والاستخدام والأسعار", icon: "Package" },
  { slug: "registration", name: "التسجيل", description: "كيفية التسجيل والعضوية ورمز الراعي", icon: "UserPlus" },
  { slug: "profits", name: "الأرباح", description: "خطة التعويض والعمولات والرتب", icon: "TrendingUp" },
  { slug: "shipping", name: "الشحن", description: "التوصيل والتتبع والاسترجاع", icon: "Truck" },
  { slug: "training", name: "التدريب", description: "برامج التدريب والتطوير للأعضاء", icon: "GraduationCap" },
  { slug: "mlm", name: "التسويق الشبكي", description: "مفاهيم التسويق الشبكي والبيع المباشر", icon: "Network" },
  { slug: "objections", name: "الاعتراضات", description: "ردود جاهزة على الاعتراضات الشائعة", icon: "ShieldQuestion" },
  { slug: "support", name: "الدعم", description: "التواصل والتحيات والدعم العام", icon: "Headset" },
] as const;

const ENTRIES_BY_SLUG: Record<string, typeof PRODUCT_ENTRIES> = {
  company: COMPANY_ENTRIES,
  products: PRODUCT_ENTRIES,
  registration: REGISTRATION_ENTRIES,
  profits: PROFITS_ENTRIES,
  shipping: SHIPPING_ENTRIES,
  training: TRAINING_ENTRIES,
  mlm: MLM_ENTRIES,
  objections: OBJECTION_ENTRIES,
  support: SUPPORT_ENTRIES,
};

const DEFAULT_SETTINGS: Record<string, string> = {
  whatsapp: "218946098624",
  sponsorCode: "829134401",
  registerLink: "https://eworld.dxn2u.com/s/accreg/ar/829134401",
  notifyEmail: "",
  facebook: "",
  instagram: "",
  aiFallbackEnabled: "true",
  welcomeMessage:
    "مرحبًا بك 👋 أنا المساعد الذكي لمنصة DXN. اسألني عن المنتجات أو التسجيل أو الأرباح، أو استخدم الأزرار السريعة بالأسفل.",
};

async function main() {
  const db = getDb();

  const [{ c }] = await db.select({ c: count() }).from(categories);
  if (c > 0) {
    console.log(`قاعدة المعرفة مزروعة مسبقًا (${c} أقسام) — لا شيء للقيام به.`);
    process.exit(0);
  }

  // الأقسام
  for (let i = 0; i < CATEGORIES.length; i++) {
    const cat = CATEGORIES[i];
    const [{ id: categoryId }] = await db
      .insert(categories)
      .values({ ...cat, sortOrder: i })
      .$returningId();

    const entries = ENTRIES_BY_SLUG[cat.slug] ?? [];
    // إدخال الأسئلة على دفعات
    for (const e of entries) {
      const [{ id: qaId }] = await db
        .insert(qaEntries)
        .values({
          categoryId,
          question: e.q,
          keywords: e.keywords.join(", "),
        })
        .$returningId();

      await db.insert(qaAnswers).values(
        e.a.map((ans, idx) =>
          typeof ans === "string"
            ? { qaId, body: ans, sortOrder: idx }
            : {
                qaId,
                body: ans.body,
                showWhatsapp: !!ans.whatsapp,
                linkUrl: ans.link ?? null,
                linkLabel: ans.linkLabel ?? null,
                sortOrder: idx,
              },
        ),
      );
    }
    console.log(`✔ ${cat.name}: ${entries.length} سؤال`);
  }

  // الإعدادات الافتراضية
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db
      .insert(settings)
      .values({ key, value })
      .onDuplicateKeyUpdate({ set: { value } });
  }

  const [{ c: totalQa }] = await db.select({ c: count() }).from(qaEntries);
  const [{ c: totalAns }] = await db.select({ c: count() }).from(qaAnswers);
  console.log(`\nتم الزرع بنجاح: ${totalQa} سؤال · ${totalAns} إجابة · ${CATEGORIES.length} أقسام`);
  process.exit(0);
}

main().catch((err) => {
  console.error("فشل الزرع:", err);
  process.exit(1);
});
